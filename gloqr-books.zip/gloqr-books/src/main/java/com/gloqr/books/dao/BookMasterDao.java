package com.gloqr.books.dao;

import java.util.List;
import java.util.Map;

import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.entities.CustomerNotes;
import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SalesPerson;
//import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TermsAndConditions;

public interface BookMasterDao {

	void saveSelfMasterDetails(SelfMaster selfMaster);
	
	Map<String, Boolean> getBookStatus(String userUuid);
	
	String saveGstTreatment(GstTreatment gstTreatment);
	
	List<GstTreatmentDto> getGstTreatment();
	
	void savePaymentTermsDetails(PaymentTerms paymentTerms);
	
	void saveSalesPersonDetails(SalesPerson salesPerson);
	
	void saveCustomerNotes(CustomerNotes customerNotes);
	
	void saveTermsAndConditions(TermsAndConditions termsAndConditions);
	
	Map<String,String> getBookUuid(String userUuid);
}
