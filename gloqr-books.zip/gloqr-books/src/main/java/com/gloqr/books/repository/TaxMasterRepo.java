package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.entities.TaxMaster;

public interface TaxMasterRepo extends JpaRepository<TaxMaster,Long>{
	
//	List<TaxMaster> findAll();
	
	TaxMaster findByTaxMasterUuid(String taxMasterUuid);

}
