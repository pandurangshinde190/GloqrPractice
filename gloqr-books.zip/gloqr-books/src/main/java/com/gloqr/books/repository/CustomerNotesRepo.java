package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.CustomerNotes;

public interface CustomerNotesRepo extends JpaRepository<CustomerNotes, Long>{
	
	CustomerNotes findByCustomerNotesUuid(String customerNotesUuid);
	
	List<CustomerNotes> findByBookUuid(String bookUuid);

}
