package com.gloqr.books.endpoints;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.file.FileDataBodyPart;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.exception.CustomException;
import com.gloqr.books.model.http.response.UploadFileResponse;



public class ContentServerEndpoint {

	private Client client;
	private String endPointUri;
	private String uploadMultipleFile;
	private String deleteFiles;

	private static final Logger log = LogManager.getLogger();

	public ContentServerEndpoint(Client client, String endPointUri, String uploadMultipleFile, String deleteFiles) {
		this.client = client;
		this.endPointUri = endPointUri;
		this.uploadMultipleFile = uploadMultipleFile;
		this.deleteFiles = deleteFiles;
	}

	public List<UploadFileResponse> sendFilesToContentServer(List<MultipartFile> multipartFiles, List<String> name,
			String location) throws IOException {

		log.info("uploading files to content server");
		log.info("Connecting to content server...  [method=POST ,uri= {}{}/{} ,body= fileObjs }", endPointUri,
				uploadMultipleFile, location);

		Response response = null;
		List<File> files = null;
		List<UploadFileResponse> fileResponse = null;
		int i = 0;
		try (MultiPart multiPart = new MultiPart()) {
			WebTarget webTarget = client.target(endPointUri).path(uploadMultipleFile).path(location);
			multiPart.setMediaType(MediaType.MULTIPART_FORM_DATA_TYPE);
			files = new ArrayList<>();
			for (MultipartFile file : multipartFiles) {
				File tmpfile = convert(file, name.get(i++));
				FileDataBodyPart fileDataBodyPart = new FileDataBodyPart("files", tmpfile,
						MediaType.APPLICATION_OCTET_STREAM_TYPE);
				multiPart.bodyPart(fileDataBodyPart);
				files.add(tmpfile);
			}
			try {
				response = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
						.post(Entity.entity(multiPart, multiPart.getMediaType()));
			} catch (Exception e) {
				throwConnectionRefusedException(e);
			}
			logResponse(response);
			Integer statusCode = response.getStatus();
			if (statusCode != HttpStatus.OK.value()) {
				throwInvalidResponseException(statusCode);
			}

			try {
				fileResponse = response.readEntity(new GenericType<List<UploadFileResponse>>() {
				});
			} catch (Exception e) {
				throwEntityResponseReadException(e);
			}
			return fileResponse;

		} finally {
			if (files != null && !files.isEmpty()) {
				for (File file : files) {
					cleanUp(file.toPath());
				}
			}
		}

	}

	private void cleanUp(Path path) throws IOException {
		Files.delete(path);
	}

	public File convert(MultipartFile file, String name) throws IOException {

		File convFile = new File(name);
		if (convFile.createNewFile()) {
			try (FileOutputStream fos = new FileOutputStream(convFile)) {

				fos.write(file.getBytes());
			} catch (Exception e) {
				log.info("Auto Closeable interfaces");
			}
			return convFile;
		} else {
			throw new CustomException("File not created Locally,while Sending file to Content Server",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Async("taskExecutor")
	public void deleteFilesFromContentServer(List<String> fileLocations) {
		log.info("Deleting files from content server. Deleting Locations :- {}", fileLocations);
		Response response = null;
		Client client1 = ClientBuilder.newClient();
		try {
			response = client1.target(endPointUri).path(deleteFiles).queryParam("fileLocations", fileLocations)
					.request(MediaType.APPLICATION_JSON).delete();
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		Integer responseCode = response.getStatus();

		if (responseCode != HttpStatus.OK.value()) {
			throw new CustomException("Problem for delete image from content server", HttpStatus.CONFLICT);
		}

	}

	private void throwEntityResponseReadException(Exception e) {
		throw new CustomException("Exception at read response from Content Server Module. Message: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void throwInvalidResponseException(int statusCode) {
		throw new CustomException("Invalid Response from Content Server Module: ", HttpStatus.resolve(statusCode));
	}

	private void throwConnectionRefusedException(Exception e) {
		throw new CustomException("Couldn't Connect to Content Server module, Exception: " + e.getMessage(),
				HttpStatus.INTERNAL_SERVER_ERROR, e);
	}

	private void logResponse(Response response) {
		log.info("Response From Content Server Module : " + response);
	}

}
