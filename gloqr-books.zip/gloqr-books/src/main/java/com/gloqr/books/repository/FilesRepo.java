package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.Files;

public interface FilesRepo extends JpaRepository<Files, Long>{

	Files findByFilesUuid(String filesUuid);
	
	List<Files> findBySalesOrderUuid(String salesOrderUuid);
}
