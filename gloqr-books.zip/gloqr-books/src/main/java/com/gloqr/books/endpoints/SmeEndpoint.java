package com.gloqr.books.endpoints;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.SMEInfoDto;
import com.gloqr.books.exception.CustomException;


public class SmeEndpoint {
	private Client client;
	private String endpoint;
	private String smeDetailPath;


	Logger logger = LogManager.getLogger();

	public SmeEndpoint(Client client, String endpoint, String smeDetailPath) {
		this.client = client;
		this.endpoint = endpoint;
		this.smeDetailPath = smeDetailPath;
		
	}
	
	public SMEInfoDto getSmeInformation(String userId) {

		logger.info("Getting SME Details by ID :: " + userId);

		Response response = null;
		CustomHttpResponse<SMEInfoDto> httpResponse = null;

		try {
			response = client.target(endpoint).path(smeDetailPath.replace("{userId}", userId))
					.request(MediaType.APPLICATION_JSON).get();

			logger.info("Response from SME endpoint :: " + response.toString());

			httpResponse = response.readEntity(new GenericType<CustomHttpResponse<SMEInfoDto>>() {
			});

			if (httpResponse.isError()) {
				throw new CustomException(httpResponse.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				return httpResponse.getData();
			}
		} catch (Exception e) {
			throw new CustomException("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}


}
