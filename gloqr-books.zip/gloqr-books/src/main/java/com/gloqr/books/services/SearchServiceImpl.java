package com.gloqr.books.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.lucene.search.Query;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.books.dto.ItemListDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.SelfMasterRepo;

@Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	SelfMasterRepo selfMasterRepo;

	@Autowired
	Mapper mapper;

	

	@Override
	public List<ItemListDto> getSearchItemSuggestions(String searchText, int maxResult, String uuid) {

		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);	

		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);

		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
				.forEntity(ItemMaster.class).get();

		Query query1 = queryBuilder.keyword().onField("name").matching(searchText).createQuery();

		Query finalQuery = queryBuilder.bool().must(query1).must(activeQuery(queryBuilder,selfMaster.getBookUuid())).createQuery();

		FullTextQuery queryResult = fullTextEntityManager.createFullTextQuery(finalQuery, ItemMaster.class);
		queryResult.setMaxResults(maxResult);

		@SuppressWarnings("unchecked")
		List<ItemMaster> results = queryResult.getResultList();

		List<ItemListDto> itemList = new ArrayList<>();

		for (ItemMaster item : results) {
			ItemListDto itemDto = mapper.convertToDto(item, ItemListDto.class);
			if(item.getUom()!=null) {
				UOMMasterDto uomMasterDto = mapper.convertToDto(item.getUom(),UOMMasterDto.class);
				itemDto.setUomMasterDto(uomMasterDto);
			}
			itemList.add(itemDto);
		}
		return itemList;

	}



	private Query activeQuery(QueryBuilder queryBuilder, String bookUuid) {
		return queryBuilder.keyword().onField("bookUuid").matching(bookUuid).createQuery();
	}
}
