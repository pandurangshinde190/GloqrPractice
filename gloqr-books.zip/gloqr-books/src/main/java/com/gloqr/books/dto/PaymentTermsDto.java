package com.gloqr.books.dto;


public class PaymentTermsDto {

	private String paymentTermsUuid;


	private String termName;

	private int numberOfDays;
	

	private String bookUuid;

	public String getPaymentTermsUuid() {
		return paymentTermsUuid;
	}

	public void setPaymentTermsUuid(String paymentTermsUuid) {
		this.paymentTermsUuid = paymentTermsUuid;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public int getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}
	
	

}
