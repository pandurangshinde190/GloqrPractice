package com.gloqr.books.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.stereotype.Component;

import com.gloqr.books.configuration.PropertyValues;
import com.gloqr.books.security.context.holder.IContextHolder;

@Component
public class PaginationUtils implements IContextHolder {
	
	@Autowired
	private PropertyValues propertyValues;
	
	/*	public int getPageSize() {
		
		
		 * int pageSize = propertyValues.getNormalPageSize();
		 * 
		 * Device device =
		 * DeviceUtils.getCurrentDevice(this.getCurrentServletRequest());
		 * 
		 * if(device.isMobile()) { pageSize = propertyValues.getMobilePageSize(); } else
		 * { pageSize = propertyValues.getTabletPageSize(); } return pageSize;
		 */
	}

