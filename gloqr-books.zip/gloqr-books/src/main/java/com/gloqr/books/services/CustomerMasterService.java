package com.gloqr.books.services;

import java.util.List;

import com.gloqr.books.dto.BusinessUnitDto;
import com.gloqr.books.dto.CustomerListDto;
import com.gloqr.books.dto.CustomerMasterDto;
import com.gloqr.books.dto.CustomerMasterVO;

public interface CustomerMasterService {

	String saveCustomerMasterDetails(CustomerMasterDto customerMasterDto,String uuid);
	
	String saveBusinessUnitDetails(BusinessUnitDto businessUnitDto,String uuid);
	
	List<BusinessUnitDto> getBusinessUnits(String userUuid);
	
	List<CustomerMasterVO> getCustomerMasterDetails(String uuid,int page);
	
	List<CustomerListDto> getCustomerList(String uuid);
	
	CustomerMasterVO getCustomer(String customerMUuid);
	
	String updateCustomerMaster(CustomerMasterDto customerMasterDto,String uuid);
}
