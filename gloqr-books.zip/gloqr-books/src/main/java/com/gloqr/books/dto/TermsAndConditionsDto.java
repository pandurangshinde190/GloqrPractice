package com.gloqr.books.dto;

public class TermsAndConditionsDto {

	private String termsUuid;

	private String type;

	private String name;

	private String description;

	private String bookUuid;


	public String getTermsUuid() {
		return termsUuid;
	}

	public void setTermsUuid(String termsUuid) {
		this.termsUuid = termsUuid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	
}
