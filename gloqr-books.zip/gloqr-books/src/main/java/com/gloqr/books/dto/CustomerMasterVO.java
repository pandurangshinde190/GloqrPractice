package com.gloqr.books.dto;

import java.util.List;
import java.util.Set;

import com.gloqr.books.constants.CustomerType;

public class CustomerMasterVO {

	private String customerMUuid;

	private String contactPhone;

	private String contactMobile;

	private String contactEmail;

	private String website;

	private String customerName;

	private String vendorCode;

	private GstTreatmentDto gstTreatment;

	private double openingBalance;

	private PaymentTermsDto paymentTerms;

	private int creditDays;

	private CustomerType customerType;

//	private BusinessUnitDto businessUnit;

	private String bookUuid;

	private List<ContactPersonDto> contactPersons;

	private List<ConsigneePersonDto> consigneePersons;

	private List<BusinessUnitDto> businessUnits;

//	private ConsigneePersonDto consigneePerson;

	/*
	 * private AddressDto billingAddress;
	 * 
	 * private AddressDto shippingAddress;
	 */

	

	public String getCustomerMUuid() {
		return customerMUuid;
	}

	public void setCustomerMUuid(String customerMUuid) {
		this.customerMUuid = customerMUuid;
	}


	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}


	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}


	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public GstTreatmentDto getGstTreatment() {
		return gstTreatment;
	}

	public void setGstTreatment(GstTreatmentDto gstTreatment) {
		this.gstTreatment = gstTreatment;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public PaymentTermsDto getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(PaymentTermsDto paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public int getCreditDays() {
		return creditDays;
	}

	public void setCreditDays(int creditDays) {
		this.creditDays = creditDays;
	}

	public CustomerType getCustomerType() {
		return customerType;
	}

	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	

	public List<ContactPersonDto> getContactPersons() {
		return contactPersons;
	}

	public void setContactPersons(List<ContactPersonDto> contactPersons) {
		this.contactPersons = contactPersons;
	}

	public List<ConsigneePersonDto> getConsigneePersons() {
		return consigneePersons;
	}

	public void setConsigneePersons(List<ConsigneePersonDto> consigneePersons) {
		this.consigneePersons = consigneePersons;
	}

	public List<BusinessUnitDto> getBusinessUnits() {
		return businessUnits;
	}

	public void setBusinessUnits(List<BusinessUnitDto> businessUnits) {
		this.businessUnits = businessUnits;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

}
