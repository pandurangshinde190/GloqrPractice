package com.gloqr.books.dto;

import com.gloqr.books.constants.TaxPreference;
import com.gloqr.books.entities.AccountMaster;
import com.gloqr.books.entities.TaxMaster;
import com.gloqr.books.entities.UOM;

public class ItemMasterVO {


	private ItemMasterDto itemMasterDto;

	private AccountMasterDto salesAccountDto;
	
	private AccountMasterDto purchaseAccountDto;

	private UOMMasterDto uomMasterDto;

	private TaxMasterDto taxMasterDto;

	
	public ItemMasterDto getItemMasterDto() {
		return itemMasterDto;
	}

	public void setItemMasterDto(ItemMasterDto itemMasterDto) {
		this.itemMasterDto = itemMasterDto;
	}

	public AccountMasterDto getSalesAccountDto() {
		return salesAccountDto;
	}

	public void setSalesAccountDto(AccountMasterDto salesAccountDto) {
		this.salesAccountDto = salesAccountDto;
	}

	public AccountMasterDto getPurchaseAccountDto() {
		return purchaseAccountDto;
	}

	public void setPurchaseAccountDto(AccountMasterDto purchaseAccountDto) {
		this.purchaseAccountDto = purchaseAccountDto;
	}

	public UOMMasterDto getUomMasterDto() {
		return uomMasterDto;
	}

	public void setUomMasterDto(UOMMasterDto uomMasterDto) {
		this.uomMasterDto = uomMasterDto;
	}

	public TaxMasterDto getTaxMasterDto() {
		return taxMasterDto;
	}

	public void setTaxMasterDto(TaxMasterDto taxMasterDto) {
		this.taxMasterDto = taxMasterDto;
	}

		
	

}
