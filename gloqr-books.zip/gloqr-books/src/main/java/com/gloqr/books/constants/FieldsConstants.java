package com.gloqr.books.constants;

public class FieldsConstants {

	private FieldsConstants() {
		throw new IllegalStateException("FieldsConstants class.can't initiate");
	}

	public static final String ITEM_NAME = "name";
	public static final String BOOK_UUID = "bookUuid";

}
