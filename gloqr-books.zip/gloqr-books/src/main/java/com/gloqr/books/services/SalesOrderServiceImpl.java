package com.gloqr.books.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.dao.ItemMasterDao;
import com.gloqr.books.dao.SalesOrderDao;
import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.dto.ConsigneePersonListDto;
import com.gloqr.books.dto.ContactPersonListDto;
import com.gloqr.books.dto.FilesDto;
import com.gloqr.books.dto.OrderItemDto;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.SalesOrderVO;
import com.gloqr.books.entities.BusinessUnit;
import com.gloqr.books.entities.ConsigneePerson;
import com.gloqr.books.entities.ContactPerson;
import com.gloqr.books.entities.CustomerMaster;
import com.gloqr.books.entities.CustomerNotes;
import com.gloqr.books.entities.Files;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.OrderItem;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SalesOrder;
import com.gloqr.books.entities.SalesPerson;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TermsAndConditions;
import com.gloqr.books.entities.UOM;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.BusinessUnitRepo;
import com.gloqr.books.repository.ConsigneePersonRepo;
import com.gloqr.books.repository.ContactPersonRepo;
import com.gloqr.books.repository.CustomerMasterRepo;
import com.gloqr.books.repository.CustomerNotesRepo;
import com.gloqr.books.repository.FilesRepo;
import com.gloqr.books.repository.ItemMasterRepo;
import com.gloqr.books.repository.OrderItemRepo;
import com.gloqr.books.repository.PaymentTermsRepo;
import com.gloqr.books.repository.SalesOrderRepo;
import com.gloqr.books.repository.SalesPersonRepo;
import com.gloqr.books.repository.SelfMasterRepo;
import com.gloqr.books.repository.TermsAndConditionsRepo;
import com.gloqr.books.repository.UOMMasterRepo;
import com.gloqr.books.util.UuidUtil;

@Service
public class SalesOrderServiceImpl implements SalesOrderService {

	@Autowired
	CustomerMasterRepo customerMasterRepo;

	@Autowired
	PaymentTermsRepo paymentTermsRepo;

	@Autowired
	SalesPersonRepo salesPersonRepo;

	@Autowired
	CustomerNotesRepo customerNotesRepo;

	@Autowired
	TermsAndConditionsRepo termsAndConditionsRepo;

	@Autowired
	Mapper mapper;

	@Autowired
	SalesOrderDao salesOrderDao;

	@Autowired
	FilesRepo filesRepo;

	@Autowired
	SelfMasterRepo selfMasterRepo;

	@Autowired
	SalesOrderRepo salesOrderRepo;

	@Autowired
	OrderItemRepo orderItemRepo;

	@Autowired
	UOMMasterRepo uomMasterRepo;
	
	@Autowired
	ItemMasterRepo itemMasterRepo;
	
	@Autowired
	ItemMasterDao itemMasterDao;
	
	@Autowired
	BusinessUnitRepo businessUnitRepo;
	
	@Autowired
	ContactPersonRepo contactPersonRepo;
	
	@Autowired
	ConsigneePersonRepo consigneePersonRepo;
	
	@Override
	public String saveSalesOrderDetails(SalesOrderDto salesOrderDto, String suuid) {

		try {
			SelfMaster selfMaster = selfMasterRepo.findBySuuid(suuid);
			salesOrderDto.setBookUuid(selfMaster.getBookUuid());
			CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(salesOrderDto.getCustomerMUuid());
			PaymentTerms paymentTerms = paymentTermsRepo.findByPaymentTermsUuid(salesOrderDto.getPaymentTermsUuid());
			SalesPerson salesPerson = salesPersonRepo.findBysalesPersonUuid(salesOrderDto.getSalesPersonUuid());
			BusinessUnit businessUnit = businessUnitRepo.findByBusinessUnitUuid(salesOrderDto.getBusinessUnitUuid());
			ContactPerson contactPerson = contactPersonRepo.findByContactPersonUuid(salesOrderDto.getConsigneePersonUuid());
			ConsigneePerson consigneePerson = consigneePersonRepo.findByConsigneePersonUuid(salesOrderDto.getConsigneePersonUuid());
			
			salesOrderDto.setSalesOrderUuid(UuidUtil.getUuid());

			SalesOrder salesOrder = mapper.convertToEntity(salesOrderDto, SalesOrder.class);

			salesOrder.setCustomerMaster(customerMaster);
			salesOrder.setPaymentTerms(paymentTerms);
			salesOrder.setSalesPerson(salesPerson);
			salesOrder.setBusinessUnit(businessUnit);
			salesOrder.setContactPerson(contactPerson);
			salesOrder.setConsigneePerson(consigneePerson);

			if (salesOrder.getFiles() != null) {
				List<Files> set = new ArrayList<Files>();
				for (Files file : salesOrder.getFiles()) {
//					filesRepo.findByFilesUuid(file.getFilesUuid());
					file.setSalesOrderUuid(salesOrderDto.getSalesOrderUuid());
					file.setActive(true);
					set.add(file);
				}
				salesOrder.setFiles(set);
			}
			
			if(salesOrderDto.getOrderItems()!=null) { 
				List<OrderItem> item = new ArrayList<OrderItem>();
				for (OrderItemDto orderItemDto : salesOrderDto.getOrderItems()) {
					orderItemDto.setOrderItemUuid(UuidUtil.getUuid());
					OrderItem orderItem = mapper.convertToEntity(orderItemDto, OrderItem.class);
					UOM uom = uomMasterRepo.findByuomUuid(orderItemDto.getUomUuid());
					orderItem.setUom(uom);
					item.add(orderItem);
					
					boolean isItemAvailable= itemMasterRepo.existsByNameAndBookUuid(orderItem.getItemName(), selfMaster.getBookUuid());
					System.out.println("isItemAvailable:"+isItemAvailable);
					if(!isItemAvailable) {
						addNewItem(orderItem,selfMaster.getBookUuid());
					}
				}
				salesOrder.setOrderItems(item);
			}

			/*
			 * if (salesOrder.getOrderItems() != null) { Set<OrderItem> item = new
			 * HashSet<OrderItem>(); for (OrderItem orderItem : salesOrder.getOrderItems())
			 * { orderItem.setOrderItemUuid(UuidUtil.getUuid());
			 * 
			 * 
			 * item.add(orderItem); } salesOrder.setOrderItems(item); }
			 */

			return salesOrderDao.saveSalesOrderDetails(salesOrder);

		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public List<SalesOrderVO> getSalesOrderDetails(String uuid, int page) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		return salesOrderDao.getSalesOrderDetails(selfMaster.getBookUuid(), page);
	}

	@Override
	public SalesOrderVO getSalesOrder(String salesOrderUuid) {
		// TODO Auto-generated method stub
		return salesOrderDao.getSalesOrder(salesOrderUuid);
	}

	@Override
	public String updateSalesOrder(SalesOrderDto salesOrderDto) {

		SalesOrder salesOrder = salesOrderRepo.findBySalesOrderUuid(salesOrderDto.getSalesOrderUuid());
		salesOrder.setSalesOrderNumber(salesOrderDto.getSalesOrderNumber());
		salesOrder.setReferenceNumber(salesOrderDto.getReferenceNumber());
		salesOrder.setSalesOrderDate(salesOrderDto.getSalesOrderDate());
		salesOrder.setExpectedShipmentDate(salesOrderDto.getExpectedShipmentDate());
		salesOrder.setDeliveryMethod(salesOrderDto.getDeliveryMethod());
		salesOrder.setCustomerNotes(salesOrderDto.getCustomerNotes());
		salesOrder.setTotal(salesOrderDto.getTotal());
		salesOrder.setTermsAndConditions(salesOrderDto.getTermsAndConditions());
		salesOrder.setSubTotal(salesOrderDto.getSubTotal());
		salesOrder.setRoundOff(salesOrderDto.getRoundOff());
		salesOrder.setSalesOrderStatus(salesOrderDto.getSalesOrderStatus());
		salesOrder.setActive(true);

		if (salesOrderDto.getCustomerMUuid() != null) {
			CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(salesOrderDto.getCustomerMUuid());
			salesOrder.setCustomerMaster(customerMaster);
		}
		if (salesOrderDto.getPaymentTermsUuid() != null) {
			PaymentTerms paymentTerms = paymentTermsRepo.findByPaymentTermsUuid(salesOrderDto.getPaymentTermsUuid());
			salesOrder.setPaymentTerms(paymentTerms);
		}
		if (salesOrderDto.getSalesPersonUuid() != null) {
			SalesPerson salesPerson = salesPersonRepo.findBysalesPersonUuid(salesOrderDto.getSalesPersonUuid());
			salesOrder.setSalesPerson(salesPerson);
		}
		if(salesOrderDto.getBusinessUnitUuid()!=null) {
			BusinessUnit businessUnit = businessUnitRepo.findByBusinessUnitUuid(salesOrderDto.getBusinessUnitUuid());
			salesOrder.setBusinessUnit(businessUnit);
		}
		if(salesOrderDto.getContactPersonUuid()!=null) {
			ContactPerson contactPerson = contactPersonRepo.findByContactPersonUuid(salesOrderDto.getContactPersonUuid());
			salesOrder.setContactPerson(contactPerson);
		}
		if(salesOrderDto.getConsigneePersonUuid()!=null) {
			ConsigneePerson consigneePerson = consigneePersonRepo.findByConsigneePersonUuid(salesOrderDto.getConsigneePersonUuid());
			salesOrder.setConsigneePerson(consigneePerson);
		}
		if (salesOrderDto.getOrderItems() != null) {
			List<OrderItem> item = new ArrayList<OrderItem>();
			OrderItem orderItem = new OrderItem();
			for (OrderItemDto orderItemDto : salesOrderDto.getOrderItems()) {
				if (orderItemDto.getOrderItemUuid() != null) {
					orderItem = orderItemRepo.findByOrderItemUuid(orderItemDto.getOrderItemUuid());
					orderItem = updateOrderItem(orderItem, orderItemDto);
				} else {
					orderItemDto.setOrderItemUuid(UuidUtil.getUuid());
					orderItem = mapper.convertToEntity(orderItemDto, OrderItem.class);
					UOM uom = uomMasterRepo.findByuomUuid(orderItemDto.getUomUuid());
					orderItem.setUom(uom);
					
					boolean isItemAvailable= itemMasterRepo.existsByNameAndBookUuid(orderItem.getItemName(), salesOrder.getBookUuid());
					System.out.println("isItemAvailable:"+isItemAvailable);
					if(!isItemAvailable) {
						addNewItem(orderItem,salesOrder.getBookUuid());
					}
				}
				item.add(orderItem);
			}
			salesOrder.setOrderItems(item);
		}

		
		List<Files> fileList = filesRepo.findBySalesOrderUuid(salesOrderDto.getSalesOrderUuid());
		if(fileList!=null) {
			for(int i=0;i<fileList.size();i++) {
				fileList.get(i).setActive(false);
				fileList.get(i).setSalesOrderUuid(null);
			}
			salesOrderDao.updateFiles(fileList);
		}
		
		if (salesOrderDto.getFiles() != null) {
			List<Files> files = new ArrayList<Files>();
			Files file = new Files();
			for (FilesDto filesDto : salesOrderDto.getFiles()) {
				file = filesRepo.findByFilesUuid(filesDto.getFilesUuid());
				if(file!=null) {
					file.setActive(true);
					file.setSalesOrderUuid(salesOrderDto.getSalesOrderUuid());
				}else {
					file = mapper.convertToEntity(filesDto, Files.class);
					file.setActive(true);
					file.setSalesOrderUuid(salesOrderDto.getSalesOrderUuid());
				}
			
				files.add(file);
			}
			
			//List<Files> fileList = filesRepo.findBySalesOrderUuid(salesOrderDto.getSalesOrderUuid());
			
			salesOrder.setFiles(files);
		}
		
		return salesOrderDao.updateSalesOrder(salesOrder);
	}

	public OrderItem updateOrderItem(OrderItem orderItem, OrderItemDto orderItemDto) {
		orderItem.setItemName(orderItemDto.getItemName());
		orderItem.setQuantity(orderItemDto.getQuantity());
		orderItem.setRate(orderItemDto.getRate());
		orderItem.setDiscount(orderItemDto.getDiscount());
		orderItem.setTax(orderItemDto.getTax());
		orderItem.setAmount(orderItemDto.getAmount());
		orderItem.setDiscountType(orderItemDto.getDiscountType());
		orderItem.setHsnSacCode(orderItemDto.getHsnSacCode());
		UOM uom=uomMasterRepo.findByuomUuid(orderItemDto.getUomUuid());
		if(uom!=null) {
			orderItem.setUom(uom);
		}
		return orderItem;
	}

	/*
	 * public Files updateFiles(Files file, FilesDto filesDto) {
	 * file.setName(filesDto.getName()); file.setType(filesDto.getType());
	 * file.setLocation(filesDto.getLocation()); file.setSize(filesDto.getSize());
	 * file.setReferenceId(filesDto.getReferenceId()); return file; }
	 */
	
	
	public void addNewItem(OrderItem orderItem,String bookUuid) {
		ItemMaster itemMaster =new ItemMaster();
		itemMaster.setBookUuid(bookUuid);
		itemMaster.setName(orderItem.getItemName());
		itemMaster.setHsnSacCode(orderItem.getHsnSacCode());
		itemMaster.setSellingPrice(orderItem.getRate());
		itemMaster.setType(orderItem.getType());
		itemMaster.setItemMasterUuid(UuidUtil.getUuid(orderItem.getItemName()));
		itemMasterDao.saveItemMaster(itemMaster);
	}

	@Override
	public List<BusinessUnitListDto> getBusinessUnitForCustomer(String customerMUuid) {
		CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(customerMUuid);
//		List<BusinessUnit> businessUnits = customerMaster.getBusinessUnits();
		List<BusinessUnitListDto> businessUnitListDtos=new ArrayList<BusinessUnitListDto>();
		for(BusinessUnit businessUnit:customerMaster.getBusinessUnits()) {
			if(businessUnit!=null) {
				BusinessUnitListDto businessUnitListDto = mapper.convertToDto(businessUnit, BusinessUnitListDto.class);
				businessUnitListDtos.add(businessUnitListDto);
			}
		}
		return businessUnitListDtos;
	}

	@Override
	public List<ContactPersonListDto> getContactPersonForCustomer(String customerMUuid) {
		CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(customerMUuid);
		List<ContactPersonListDto> contactPersonListDtos=new ArrayList<ContactPersonListDto>();
		for(ContactPerson contactPerson:customerMaster.getContactPersons()) {
			if(contactPerson!=null) {
				ContactPersonListDto contactPersonListDto = mapper.convertToDto(contactPerson, ContactPersonListDto.class);
				contactPersonListDtos.add(contactPersonListDto);
			}
		}
		
		return contactPersonListDtos;
	}

	@Override
	public List<ConsigneePersonListDto> getConsigneePersonForCustomer(String customerMUuid) {
		CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(customerMUuid);
		List<ConsigneePersonListDto> consigneePersonListDtos=new ArrayList<ConsigneePersonListDto>();
		for(ConsigneePerson consigneePerson:customerMaster.getConsigneePersons()) {
			if(consigneePerson!=null) {
				ConsigneePersonListDto consigneePersonListDto= mapper.convertToDto(consigneePerson, ConsigneePersonListDto.class);
				consigneePersonListDtos.add(consigneePersonListDto);
			}
		}
		return consigneePersonListDtos;
	}

	@Override
	public Map<String, String> getSelfMasterState(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		Map<String,String> selfMasterState = new HashMap<String,String>();
		selfMasterState.put("state", selfMaster.getSmeState());
		return selfMasterState;
	}	
	
}
