package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.TermsAndConditions;

public interface TermsAndConditionsRepo extends JpaRepository<TermsAndConditions, Long>{

	TermsAndConditions findByTermsUuid(String termsUuid);
	
	List<TermsAndConditions> findByBookUuid(String bookUuid);
}
