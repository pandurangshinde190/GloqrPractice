package com.gloqr.books.services;

import java.util.List;
import java.util.Map;

import com.gloqr.books.dto.CustomerNotesDto;
import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.PaymentTermsDto;
import com.gloqr.books.dto.SalesPersonDto;
import com.gloqr.books.dto.TermsAndConditionsDto;

public interface BookMasterService {

	String saveSelfMasterDetails(String userUuid);
	
	Map<String, Boolean> bookStatus(String userUuid);
	
	String postGstTreatment(GstTreatmentDto gstTreatmentDto);
	
	List<GstTreatmentDto> getGstTreatment();
	
	String savePaymentTerms(PaymentTermsDto paymentTermsDto,String userUuid);
	
	String saveSalesPerson(SalesPersonDto salesPersonDto,String userUuid);
	
	String saveCustomerNotes(CustomerNotesDto customerNotesDto,String userUuid);
	
	String saveTermsAndConditions(TermsAndConditionsDto termsAndConditionsDto,String userUuid);
	
	Map<String,String> getBookUuid(String userUuid);
	
	List<PaymentTermsDto> getPaymentTerms(String userUuid);
	
	List<SalesPersonDto> getSalesPersonDetials(String userUuid);
	
	List<CustomerNotesDto> getCustomerNotes(String userUuid);
	
	List<TermsAndConditionsDto> getTermsAndConditions(String userUuid);
}
