package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "b_customer_notes")
public class CustomerNotes extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="customer_notes_id")
	private Long customerNotesId;

	@Column(name = "customer_notes_uuid", nullable = false, updatable = false)
	private String customerNotesUuid;
	
	@Column(name = "type")
	private String type;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "book_uuid")
	private String bookUuid;

	public Long getCustomerNotesId() {
		return customerNotesId;
	}

	public void setCustomerNotesId(Long customerNotesId) {
		this.customerNotesId = customerNotesId;
	}

	public String getCustomerNotesUuid() {
		return customerNotesUuid;
	}

	public void setCustomerNotesUuid(String customerNotesUuid) {
		this.customerNotesUuid = customerNotesUuid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}
	
	
}
