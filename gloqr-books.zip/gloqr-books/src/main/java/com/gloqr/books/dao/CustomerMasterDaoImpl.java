package com.gloqr.books.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.CustomerListDto;
import com.gloqr.books.dto.CustomerMasterDto;
import com.gloqr.books.dto.CustomerMasterVO;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.BusinessUnit;
import com.gloqr.books.entities.CustomerMaster;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.BusinessUnitRepo;
import com.gloqr.books.repository.CustomerMasterRepo;

@Repository
public class CustomerMasterDaoImpl implements CustomerMasterDao {
	private static final Logger logger = LogManager.getLogger();

	@Autowired
	CustomerMasterRepo customerMasterRepo;

	@Autowired
	BusinessUnitRepo businessUnitRepo;

	@Autowired
	Mapper mapper;

	@Override
	public String saveCustomerMasterDetails(CustomerMaster customerMaster) {
		logger.info("saving sales order details.");
		try {
			customerMasterRepo.save(customerMaster);
		} catch (Exception e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return "customer master details has been saved successfully.";
	}

	@Override
	public String saveBusinessUnitDetails(BusinessUnit businessUnit) {
		logger.info("saving business unit details.");
		try {
			businessUnitRepo.save(businessUnit);
		} catch (Exception e) {
			throw new CustomException("Error while saving business unit details", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return "Business unit details has been saved successfully.";
	}

	@Override
	public List<CustomerMasterVO> getCustomerMasterDetails(String bookUuid, int page) {
		if (page <= 0)
			page = 1;
		List<CustomerMaster> customerMasters = customerMasterRepo.findByBookUuid(bookUuid, PageRequest.of(--page, 20));
		List<CustomerMasterVO> customerMasterVOs = new ArrayList<CustomerMasterVO>();

		for (CustomerMaster customerMaster : customerMasters) {
			CustomerMasterVO customerMasterVO = new CustomerMasterVO();
			customerMasterVO = mapper.convertToDto(customerMaster, CustomerMasterVO.class);
			customerMasterVOs.add(customerMasterVO);
		}

		return customerMasterVOs;
	}

	@Override
	public List<CustomerListDto> getCustomerList(String bookUuid) {
		List<CustomerMaster> customerMasters = customerMasterRepo.findByBookUuid(bookUuid);
		List<CustomerListDto> customerList = new ArrayList<CustomerListDto>();

		for (CustomerMaster customerMaster : customerMasters) {
			CustomerListDto customerListDto = new CustomerListDto();
			customerListDto = mapper.convertToDto(customerMaster, CustomerListDto.class);
			
			customerList.add(customerListDto);
		}

		return customerList;
	}

	@Override
	public CustomerMasterVO getCustomer(String customerMUuid) {
		CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(customerMUuid);
		CustomerMasterVO customerMasterVO = mapper.convertToDto(customerMaster, CustomerMasterVO.class);
		return customerMasterVO;
	}

	@Override
	public void updateCustomerMaster(CustomerMaster customerMaster) {
		logger.info("updating customer master details.");
		try {
			customerMasterRepo.save(customerMaster);
		}catch(Exception e) {
			throw new CustomException("Error while updating customer master details", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}

}
