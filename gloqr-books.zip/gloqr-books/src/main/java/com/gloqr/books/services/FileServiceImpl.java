package com.gloqr.books.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.dao.FilesDao;
import com.gloqr.books.endpoints.ContentServerEndpoint;
import com.gloqr.books.entities.Files;
import com.gloqr.books.model.http.response.UploadFileResponse;
import com.gloqr.books.util.RandomNumber;
import com.gloqr.books.util.UuidUtil;


@Service
public class FileServiceImpl implements FileService{

	@Autowired
	FilesDao filesDao;
	
	@Autowired
	ContentServerEndpoint contentServerEndpoint;
	
	@Override
	public List<Files> sendFilesToContentServer(List<MultipartFile> multipartFiles, String fileLocation)
			throws IOException {

		List<Files> files = null;

		List<String> names = new ArrayList<>();
		multipartFiles.forEach(file -> {
			String imageName = RandomNumber.generate(1000) + file.getOriginalFilename();
			names.add(imageName);
		});

		List<UploadFileResponse> fileDetails = contentServerEndpoint.sendFilesToContentServer(multipartFiles, names,
				fileLocation);

		files = new ArrayList<>();
		for (UploadFileResponse fileDetail : fileDetails) {
			files.add(new Files(UuidUtil.getUuid(),fileDetail.getFileName(),fileDetail.getFileType(),fileDetail.getFileLocation(),fileDetail.getSize(),true));
		}

//		filesDao.saveFiles(files);

		return files;

	}
}
