package com.gloqr.books.constants;

public enum TaxPreference {
	TAXABLE,NON_TAXABLE
}
