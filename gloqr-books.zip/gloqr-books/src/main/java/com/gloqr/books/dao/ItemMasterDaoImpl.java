package com.gloqr.books.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.LedgerDto;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.AccountMaster;
import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.Ledger;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TaxMaster;
import com.gloqr.books.entities.UOM;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.AccountMasterRepo;
import com.gloqr.books.repository.ItemMasterRepo;
import com.gloqr.books.repository.LedgerRepo;
import com.gloqr.books.repository.TaxMasterRepo;
import com.gloqr.books.repository.UOMMasterRepo;

@Repository
public class ItemMasterDaoImpl implements ItemMasterDao {

	@Autowired
	ItemMasterRepo itemMasterRepo;

	@Autowired
	TaxMasterRepo taxMasterRepo;

	@Autowired
	Mapper mapper;

	@Autowired
	UOMMasterRepo uomRepo;

	@Autowired
	AccountMasterRepo accountMasterRepo;

	@Autowired
	LedgerRepo ledgerRepo;

	@Override
	public String saveItemMaster(ItemMaster itemMaster) {
		try {
			itemMasterRepo.save(itemMaster);
		} catch (Exception e) {
			throw new CustomException("Exception in saveItemMaster method. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return "Add item successfully";

	}

	@Override
	public List<TaxMasterDto> getTaxMaster() {
		List<TaxMaster> taxMasterEntity = taxMasterRepo.findAll();
		List<TaxMasterDto> taxDto = new ArrayList<TaxMasterDto>();

		for (TaxMaster obj : taxMasterEntity) {
			TaxMasterDto taxMasterDto = mapper.convertToDto(obj, TaxMasterDto.class);
			taxDto.add(taxMasterDto);
		}
		return taxDto;
	}

	@Override
	public List<UOMMasterDto> getUomMaster() {
		List<UOM> uomObj = uomRepo.findAll();
		List<UOMMasterDto> uomDto = new ArrayList<UOMMasterDto>();
		for (UOM obj : uomObj) {
			UOMMasterDto uomMasterDto = mapper.convertToDto(obj, UOMMasterDto.class);
			uomDto.add(uomMasterDto);
		}
		return uomDto;
	}

	@Override
	public List<AccountMasterDto> getAccountMaster() {
		List<AccountMaster> accountMaster = accountMasterRepo.findAll();
		List<AccountMasterDto> accountMasterDto = new ArrayList<AccountMasterDto>();

		for (AccountMaster obj : accountMaster) {
			AccountMasterDto accountMasterData = mapper.convertToDto(obj, AccountMasterDto.class);
			if(obj.getParentGroup()!=null) {
				AccountMasterDto parentAccountDto = mapper.convertToDto(obj.getParentGroup(), AccountMasterDto.class);
				accountMasterData.setParentAccountDto(parentAccountDto);
			}
			accountMasterDto.add(accountMasterData);
		}
		return accountMasterDto;
	}

	@Override
	public String saveTaxMaster(TaxMaster taxMaster) {
		try {
			taxMasterRepo.save(taxMaster);
		} catch (Exception e) {
			throw new CustomException("Exception in main class" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);

		}

		return "Add tax item successfully.";
	}

	@Override
	public String saveUomMaster(UOM uom) {
		try {
			uomRepo.save(uom);
		} catch (Exception e) {
			throw new CustomException("Exception in main class" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return "Add uom item successfully.";
	}

	public String saveAccountMaster(AccountMaster accountMaster) {
		try {
			accountMasterRepo.save(accountMaster);
		} catch (Exception e) {
			throw new CustomException("Exception in main class" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return "Add account item successfully.";
	}

	@Override
	public String saveLedgerMaster(Ledger ledger) {
		try {
			ledgerRepo.save(ledger);
		} catch (Exception e) {
			throw new CustomException("Exception in main class" + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		return "Add ledger successfully.";

	}

	@Override
	public List<LedgerDto> getLedgerMaster() {
		List<Ledger> ledger = ledgerRepo.findAll();
		List<LedgerDto> ledgerDto = new ArrayList<LedgerDto>();

		for (Ledger ledgerEntity : ledger) {
			LedgerDto ledgerMaster = mapper.convertToDto(ledgerEntity, LedgerDto.class);

			if(ledgerEntity.getAccountMaster()!=null) {
				AccountMasterDto accountMasterDto = mapper.convertToDto(ledgerEntity.getAccountMaster(), AccountMasterDto.class);
				ledgerMaster.setAccountMaster(accountMasterDto);
			}
			ledgerDto.add(ledgerMaster);			

		}
		return ledgerDto;
	}

	@Override
	public ItemMasterVO getItem(String itemUuid) {
		ItemMaster itemMaster = itemMasterRepo.findByItemMasterUuid(itemUuid);

		ItemMasterVO itemMasterVO = new ItemMasterVO();
		if(itemMaster!=null) {
			ItemMasterDto itemMasterDto = mapper.convertToDto(itemMaster, ItemMasterDto.class);
			if(itemMaster.getSalesAccount()!=null) {
				AccountMasterDto salesAccountDto = mapper.convertToDto(itemMaster.getSalesAccount(), AccountMasterDto.class);
				itemMasterVO.setSalesAccountDto(salesAccountDto);
			}
			if(itemMaster.getPurchaseAccount()!=null) {
				AccountMasterDto purchaseAccountDto = mapper.convertToDto(itemMaster.getPurchaseAccount(), AccountMasterDto.class);
				itemMasterVO.setPurchaseAccountDto(purchaseAccountDto);
			}
			if(itemMaster.getUom()!=null) {
				UOMMasterDto uomMasterDto = mapper.convertToDto(itemMaster.getUom(),UOMMasterDto.class);
				itemMasterVO.setUomMasterDto(uomMasterDto);
			}
			if(itemMaster.getTaxMaster()!=null) {
				TaxMasterDto taxMasterDto = mapper.convertToDto(itemMaster.getTaxMaster(),TaxMasterDto.class);
				itemMasterVO.setTaxMasterDto(taxMasterDto);
			}
			
			itemMasterVO.setItemMasterDto(itemMasterDto);
		}else {
			throw new CustomException("No Item Master Data Found for itemUuid "+itemUuid,HttpStatus.INTERNAL_SERVER_ERROR);			
		}
		
		
		return itemMasterVO;	

	}

	@Override
	public List<ItemMasterVO> getItemMaster(String bookUuid,int page) {	
		if (page <= 0)
			page = 1;
		List<ItemMaster> itemMaster = itemMasterRepo.findByBookUuid(bookUuid,PageRequest.of(--page, 20));
		List<ItemMasterVO> itemMasterVOs = new ArrayList<ItemMasterVO>(); 
		
		for(ItemMaster itemEntity : itemMaster) {
			ItemMasterVO itemMasterVO = new ItemMasterVO();
			ItemMasterDto itemDto = mapper.convertToDto(itemEntity, ItemMasterDto.class);
			if(itemEntity.getSalesAccount()!=null) {
				AccountMasterDto salesAccountDto = mapper.convertToDto(itemEntity.getSalesAccount(), AccountMasterDto.class);
				itemMasterVO.setSalesAccountDto(salesAccountDto);
			}
			if(itemEntity.getPurchaseAccount()!=null) {
				AccountMasterDto purchaseAccountDto = mapper.convertToDto(itemEntity.getPurchaseAccount(), AccountMasterDto.class);
				itemMasterVO.setPurchaseAccountDto(purchaseAccountDto);
			}
			if(itemEntity.getUom()!=null) {
				UOMMasterDto uomMasterDto = mapper.convertToDto(itemEntity.getUom(),UOMMasterDto.class);
				itemMasterVO.setUomMasterDto(uomMasterDto);
			}
			if(itemEntity.getTaxMaster()!=null) {
				TaxMasterDto taxMasterDto = mapper.convertToDto(itemEntity.getTaxMaster(),TaxMasterDto.class);
				itemMasterVO.setTaxMasterDto(taxMasterDto);
			}
			itemMasterVO.setItemMasterDto(itemDto);
			itemMasterVOs.add(itemMasterVO);
		}
		
		return itemMasterVOs;
	}

	public ItemMaster getItemMasterByUuid(String itemUuid) {
		ItemMaster itemMaster = itemMasterRepo.findByItemMasterUuid(itemUuid);
		if (itemMaster != null) {
			return itemMaster;
		} else {
			throw new CustomException("Item not found with uuid" + itemUuid, HttpStatus.NOT_FOUND);
		}
	}
}
