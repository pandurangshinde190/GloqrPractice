
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity

@Table(name = "b_tax_master")
public class TaxMaster extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "tax_master_id")
	private Long taxMasterId;

	@Column(name = "tax_master_uuid", nullable = false, updatable = false)
	private String taxMasterUuid;

	@Column(name = "name")
	private String name;

	@Column(name = "tyoe")
	private String type;

	@Column(name = "percentage")
	private int percentage;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "ledger_id")
	private Ledger ledgerId;
	
	

	public String getTaxMasterUuid() {
		return taxMasterUuid;
	}

	public void setTaxMasterUuid(String taxMasterUuid) {
		this.taxMasterUuid = taxMasterUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public Ledger getLedgerId() {
		return ledgerId;
	}

	public void setLedgerId(Ledger ledgerId) {
		this.ledgerId = ledgerId;
	}

}
