package com.gloqr.books.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.books.constants.Constants;
import com.gloqr.books.constants.UrlMapping;
import com.gloqr.books.dto.BusinessUnitDto;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.CustomerListDto;
import com.gloqr.books.dto.CustomerMasterDto;
import com.gloqr.books.dto.CustomerMasterVO;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.TermsAndConditionsDto;
import com.gloqr.books.services.CustomerMasterService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;

@RestController
@CrossOrigin(origins="*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class CustomerMasterController {
	
	private static final Logger logger = LogManager.getLogger();

	@Autowired
	RequestParser requestParser;

	@Autowired
	ResponseMaker responseMaker;
	
	@Autowired
	CustomerMasterService customerMasterService;
	
	@PostMapping(UrlMapping.CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveCustomerMaster(@RequestBody CustomerMasterDto customerMasterDto) {
		logger.info("Entering in saveCustomerMaster() to save customer details.");

		String uuid=requestParser.getUserUUID();
		return responseMaker.successResponse(customerMasterService.saveCustomerMasterDetails(customerMasterDto,uuid), HttpStatus.CREATED);
	
	}	
	
	@GetMapping(UrlMapping.CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<CustomerMasterVO>>> getCustomerMasterDetails(@RequestParam int page) {
		logger.info("Getting all customer master detials from database");
		String uuid=requestParser.getUserUUID();
		List<CustomerMasterVO> customerMasterVOs = customerMasterService.getCustomerMasterDetails(uuid, page);
		return responseMaker.successResponse(customerMasterVOs, HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.CUSTOMER_LIST)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<CustomerListDto>>> getCustomerList() {
		logger.info("Getting all customer list details from database");
		String uuid=requestParser.getUserUUID();
		List<CustomerListDto> customerListDtos = customerMasterService.getCustomerList(uuid);
		return responseMaker.successResponse(customerListDtos, HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.GET_CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<CustomerMasterVO>> getCustomerMasterDetails(@RequestParam String customerMUuid) {
		logger.info("Getting customer detail to update");
		CustomerMasterVO customerMasterVOs = customerMasterService.getCustomer(customerMUuid);
		return responseMaker.successResponse(customerMasterVOs, HttpStatus.OK);
	}
	
	@PutMapping(UrlMapping.CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateCustomer(@RequestBody CustomerMasterDto customerMasterDto) {
		logger.info("Updating a customer master details to the database");
		String uuid=requestParser.getUserUUID();
		customerMasterService.updateCustomerMaster(customerMasterDto,uuid);
		return responseMaker.successResponse("Update customer successfully", HttpStatus.OK);
	}
	
	@PostMapping(UrlMapping.BUSINESS_UNIT)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveBusinessUnit(@RequestBody BusinessUnitDto businessUnitDto) {
		logger.info("Entering in saveBusinessUnit() to save Business Unit details.");

		String uuid=requestParser.getUserUUID();
		return responseMaker.successResponse(customerMasterService.saveBusinessUnitDetails(businessUnitDto,uuid), HttpStatus.CREATED);
	
	}	
	
	@GetMapping(UrlMapping.BUSINESS_UNIT)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<BusinessUnitDto>>> getBusinessUnits() {
		logger.info("getting terms and conditions.");
		String tokenUserUuid = requestParser.getUserUUID();
		List<BusinessUnitDto> businessUnitDtos = new ArrayList<BusinessUnitDto>();
		businessUnitDtos = customerMasterService.getBusinessUnits(tokenUserUuid);
		return responseMaker.successResponse(businessUnitDtos, HttpStatus.OK);
	}

}
