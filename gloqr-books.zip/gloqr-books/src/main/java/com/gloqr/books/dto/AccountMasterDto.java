package com.gloqr.books.dto;


public class AccountMasterDto {
	
	private String accountMasterUuid;

	private String accountGroup;

	private String accountGroupName;
	
	private String percentageGroupId;
	
	private String parentGroupUuid;
	
	private AccountMasterDto parentAccountDto;

	public String getAccountMasterUuid() {
		return accountMasterUuid;
	}

	public void setAccountMasterUuid(String accountMasterUuid) {
		this.accountMasterUuid = accountMasterUuid;
	}

	public String getAccountGroup() {
		return accountGroup;
	}

	public void setAccountGroup(String accountGroup) {
		this.accountGroup = accountGroup;
	}

	public String getAccountGroupName() {
		return accountGroupName;
	}

	public void setAccountGroupName(String accountGroupName) {
		this.accountGroupName = accountGroupName;
	}

	public String getPercentageGroupId() {
		return percentageGroupId;
	}

	public void setPercentageGroupId(String percentageGroupId) {
		this.percentageGroupId = percentageGroupId;
	}

	public String getParentGroupUuid() {
		return parentGroupUuid;
	}

	public void setParentGroupUuid(String parentGroupUuid) {
		this.parentGroupUuid = parentGroupUuid;
	}

	public AccountMasterDto getParentAccountDto() {
		return parentAccountDto;
	}

	public void setParentAccountDto(AccountMasterDto parentAccountDto) {
		this.parentAccountDto = parentAccountDto;
	}
	
	

}
