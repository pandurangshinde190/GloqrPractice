package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.gloqr.books.entities.ItemMaster;

public interface ItemMasterRepo extends JpaRepository<ItemMaster, Long>{
	
	ItemMaster findByItemMasterUuid(String itemMasterUuid);
	
	
	List<ItemMaster> findByBookUuid(String bookUuid,Pageable pageable);
	
	List<ItemMaster> findByBookUuid(String bookUuid);
	
	boolean existsByNameAndBookUuid(String name,String bookUuid);



}
