package com.gloqr.books.model.http.response;

public class ResponseMessages {
	private ResponseMessages() {

	}

	public static final String SUCCESS = "Success";
	public static final String FILE_UPLODED = "File Uploaded";
}
