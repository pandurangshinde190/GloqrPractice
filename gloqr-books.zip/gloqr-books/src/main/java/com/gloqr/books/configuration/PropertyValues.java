package com.gloqr.books.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertyValues {
	
//	@Value(PropertyNames.BASE_URL)
//	private String baseUrl;
//	
//	@Value(PropertyNames.CONTENT_SERVER)
//	private String contentServer;
//	
//	@Value(PropertyNames.NORMAL_PAGE_SIZE)
//	private int normalPageSize;
//	
//	@Value(PropertyNames.MOBILE_PAGE_SIZE)
//	private int mobilePageSize;
//
//	@Value(PropertyNames.TABLET_PAGE_SIZE)
//	private int tabletPageSize;
//	
//
//		
//	public String getBaseUrl() {
//		return baseUrl;
//	}
//
//	public void setBaseUrl(String baseUrl) {
//		this.baseUrl = baseUrl;
//	}
//
//	public String getContentServer() {
//		return contentServer;
//	}
//
//	public void setContentServer(String contentServer) {
//		this.contentServer = contentServer;
//	}
//
//	public int getNormalPageSize() {
//		return normalPageSize;
//	}
//
//	public void setNormalPageSize(int normalPageSize) {
//		this.normalPageSize = normalPageSize;
//	}
//
//	public int getMobilePageSize() {
//		return mobilePageSize;
//	}
//
//	public void setMobilePageSize(int mobilePageSize) {
//		this.mobilePageSize = mobilePageSize;
//	}
//
//	public int getTabletPageSize() {
//		return tabletPageSize;
//	}
//
//	public void setTabletPageSize(int tabletPageSize) {
//		this.tabletPageSize = tabletPageSize;
//	}
//	

	public static final class PropertyNames {
		
		private PropertyNames() {
			throw new IllegalStateException("PropertyNames class.can't initiate");
		}
		
//		public static final String BASE_URL= "${base-url}";
//		public static final String CONTENT_SERVER = "${content-server}";
//		public static final String NORMAL_PAGE_SIZE = "${normal-page-size}";
//		public static final String MOBILE_PAGE_SIZE = "${mobile-page-size}";
//		public static final String TABLET_PAGE_SIZE = "${tablet-page-size}";
		
		}
		
	}

