package com.gloqr.books.services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gloqr.books.dao.CustomerMasterDao;
import com.gloqr.books.dto.AddressDto;
import com.gloqr.books.dto.BusinessUnitDto;
import com.gloqr.books.dto.ConsigneePersonDto;
import com.gloqr.books.dto.ContactPersonDto;
import com.gloqr.books.dto.CustomerListDto;
import com.gloqr.books.dto.CustomerMasterDto;
import com.gloqr.books.dto.CustomerMasterVO;
import com.gloqr.books.dto.TermsAndConditionsDto;
import com.gloqr.books.entities.Address;
import com.gloqr.books.entities.BusinessUnit;
import com.gloqr.books.entities.ConsigneePerson;
import com.gloqr.books.entities.ContactPerson;
import com.gloqr.books.entities.CustomerMaster;
import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.OrderItem;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TermsAndConditions;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.AddressRepo;
import com.gloqr.books.repository.BusinessUnitRepo;
import com.gloqr.books.repository.ConsigneePersonRepo;
import com.gloqr.books.repository.ContactPersonRepo;
import com.gloqr.books.repository.CustomerMasterRepo;
import com.gloqr.books.repository.GstTreatmentRepo;
import com.gloqr.books.repository.PaymentTermsRepo;
import com.gloqr.books.repository.SelfMasterRepo;
import com.gloqr.books.util.UuidUtil;

@Service
public class CustomerMasterServiceImpl implements CustomerMasterService {

	@Autowired
	SelfMasterRepo selfMasterRepo;
	
	@Autowired
	Mapper mapper;
	
	@Autowired
	GstTreatmentRepo gstTreatmentRepo;
	
	@Autowired
	PaymentTermsRepo paymentTermsRepo;
	
	@Autowired
	BusinessUnitRepo businessUnitRepo;
	
	@Autowired
	ConsigneePersonRepo consigneePersonRepo;
	
	@Autowired
	CustomerMasterDao customerMasterDao;
	
	@Autowired
	CustomerMasterRepo customerMasterRepo;
	
	@Autowired
	ContactPersonRepo contactPersonRepo;
	
	@Autowired
	AddressRepo addressRepo;
	
	@Override
	public String saveCustomerMasterDetails(CustomerMasterDto customerMasterDto, String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		customerMasterDto.setBookUuid(selfMaster.getBookUuid());
		CustomerMaster customerMaster = mapper.convertToEntity(customerMasterDto, CustomerMaster.class);
		customerMaster.setCustomerMUuid(UuidUtil.getUuid(customerMaster.getCustomerName()));
		/*
		 * customerMaster.getBillingAddress().setAddrsUuid(UuidUtil.getUuid());
		 * customerMaster.getShippingAddress().setAddrsUuid(UuidUtil.getUuid());
		 */
		
		if (customerMaster.getContactPersons()!=null) {
			List<ContactPerson> contactPersons = new ArrayList<ContactPerson>();
			for (ContactPerson contactPerson : customerMaster.getContactPersons()) {
				contactPerson.setContactPersonUuid(UuidUtil.getUuid(contactPerson.getContactPersonName()));
				contactPersons.add(contactPerson);
			}
			customerMaster.setContactPersons(contactPersons);
		}
		
		if(customerMasterDto.getGstTreatmentUuid()!=null) {
			GstTreatment gstTreatment = gstTreatmentRepo.findByGstTreatmentUuid(customerMasterDto.getGstTreatmentUuid());
			customerMaster.setGstTreatment(gstTreatment);
		}
		if(customerMasterDto.getPaymentTermsUuid()!=null) {
			PaymentTerms paymentTerms = paymentTermsRepo.findByPaymentTermsUuid(customerMasterDto.getPaymentTermsUuid());
			customerMaster.setPaymentTerms(paymentTerms);
		}
	
		if (customerMaster.getBusinessUnits()!=null) {
			List<BusinessUnit> businessUnits = new ArrayList<BusinessUnit>();
			for (BusinessUnit businessUnit : customerMaster.getBusinessUnits()) {
				businessUnit.setBusinessUnitUuid(UuidUtil.getUuid(businessUnit.getUnitName()));
				businessUnit.setBookUuid(selfMaster.getBookUuid());
				businessUnits.add(businessUnit);
			}
			customerMaster.setBusinessUnits(businessUnits);
		}
		
		if (customerMaster.getConsigneePersons()!=null) {
			List<ConsigneePerson> consigneePersons = new ArrayList<ConsigneePerson>();
			for (ConsigneePerson consigneePerson: customerMaster.getConsigneePersons()) {
				consigneePerson.setConsigneePersonUuid(UuidUtil.getUuid(consigneePerson.getConsigneePersonName()));
				consigneePersons.add(consigneePerson);
			}
			customerMaster.setConsigneePersons(consigneePersons);
		}
		
		return customerMasterDao.saveCustomerMasterDetails(customerMaster);
	}

	@Override
	public String saveBusinessUnitDetails(BusinessUnitDto businessUnitDto, String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		businessUnitDto.setBookUuid(selfMaster.getBookUuid());
		businessUnitDto.setBusinessUnitUuid(UuidUtil.getUuid());
		
//		businessUnitDto.getAddress().setAddrsUuid(UuidUtil.getUuid());
		BusinessUnit businessUnit = mapper.convertToEntity(businessUnitDto, BusinessUnit.class);
		return customerMasterDao.saveBusinessUnitDetails(businessUnit);
	}

	@Override
	public List<BusinessUnitDto> getBusinessUnits(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		List<BusinessUnit> businessUnits = businessUnitRepo.findByBookUuid(selfMaster.getBookUuid());
		List<BusinessUnitDto> businessUnitDtos = new ArrayList<BusinessUnitDto>();
		for(BusinessUnit businessUnit:businessUnits) {
			BusinessUnitDto businessUnitDto = mapper.convertToDto(businessUnit, BusinessUnitDto.class);
			businessUnitDtos.add(businessUnitDto);
		}		
		return businessUnitDtos;
	}

	@Override
	public List<CustomerMasterVO> getCustomerMasterDetails(String uuid, int page) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		return customerMasterDao.getCustomerMasterDetails(selfMaster.getBookUuid(),page);
	}

	@Override
	public List<CustomerListDto> getCustomerList(String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		return customerMasterDao.getCustomerList(selfMaster.getBookUuid());
	}

	@Override
	public CustomerMasterVO getCustomer(String customerMUuid) {
		return customerMasterDao.getCustomer(customerMUuid);
	}

	@Override
	public String updateCustomerMaster(CustomerMasterDto customerMasterDto,String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		CustomerMaster customerMaster = customerMasterRepo.findByCustomerMUuid(customerMasterDto.getCustomerMUuid());

		customerMaster.setContactPhone(customerMasterDto.getContactPhone());
		customerMaster.setContactMobile(customerMasterDto.getContactMobile());
		customerMaster.setContactEmail(customerMasterDto.getContactEmail());
		customerMaster.setWebsite(customerMasterDto.getWebsite());
		customerMaster.setVendorCode(customerMasterDto.getVendorCode());
		customerMaster.setOpeningBalance(customerMasterDto.getOpeningBalance());
		customerMaster.setCreditDays(customerMasterDto.getCreditDays());
		customerMaster.setCustomerType(customerMasterDto.getCustomerType());
		customerMaster.setCustomerName(customerMasterDto.getCustomerName());
		customerMaster.setIsDefault(customerMasterDto.getIsDefault());
		if(customerMasterDto.getGstTreatmentUuid()!=null) {
			GstTreatment gstTreatment = gstTreatmentRepo.findByGstTreatmentUuid(customerMasterDto.getGstTreatmentUuid());
			customerMaster.setGstTreatment(gstTreatment);
		}
		if(customerMasterDto.getPaymentTermsUuid()!=null) {
			PaymentTerms paymentTerms = paymentTermsRepo.findByPaymentTermsUuid(customerMasterDto.getPaymentTermsUuid());
			customerMaster.setPaymentTerms(paymentTerms);
		}
	
		
		if (customerMasterDto.getContactPersons()!=null) {
			List<ContactPerson> contactPersons = new ArrayList<ContactPerson>();			
			for (ContactPersonDto contactPersonDto : customerMasterDto.getContactPersons()) {
		
				if(contactPersonDto.getContactPersonUuid()!=null) {
					ContactPerson contactPerson = contactPersonRepo.findByContactPersonUuid(contactPersonDto.getContactPersonUuid());
					contactPerson=updateContactPerson(contactPerson,contactPersonDto);
					contactPersons.add(contactPerson);
				}else {
					contactPersonDto.setContactPersonUuid(UuidUtil.getUuid());
					ContactPerson contactPerson = mapper.convertToEntity(contactPersonDto, ContactPerson.class);
					contactPersons.add(contactPerson);
				}
				
			}
			customerMaster.setContactPersons(contactPersons);
		}
		
		
		if (customerMasterDto.getBusinessUnits()!=null) {
			List<BusinessUnit> businessUnits = new ArrayList<BusinessUnit>();			
			for (BusinessUnitDto businessUnitDto: customerMasterDto.getBusinessUnits()) {
		
				if(businessUnitDto.getBusinessUnitUuid()!=null) {
					BusinessUnit businessUnit = businessUnitRepo.findByBusinessUnitUuid(businessUnitDto.getBusinessUnitUuid());
					businessUnit=updateBusinessUnit(businessUnit,businessUnitDto,uuid);
					businessUnits.add(businessUnit);
				}else {
					businessUnitDto.setBusinessUnitUuid(UuidUtil.getUuid());
					businessUnitDto.setBookUuid(selfMaster.getBookUuid());
					BusinessUnit businessUnit = mapper.convertToEntity(businessUnitDto, BusinessUnit.class);
					businessUnits.add(businessUnit);
				}
				
			}
			customerMaster.setBusinessUnits(businessUnits);
		}
		
	
	
		
		
		if (customerMasterDto.getConsigneePersons()!=null) {
			List<ConsigneePerson> consigneePersons = new ArrayList<ConsigneePerson>();			
			for (ConsigneePersonDto consigneePersonDto : customerMasterDto.getConsigneePersons()) {
		
				if(consigneePersonDto.getConsigneePersonUuid()!=null) {
					ConsigneePerson consigneePerson = consigneePersonRepo.findByConsigneePersonUuid(consigneePersonDto.getConsigneePersonUuid());
					consigneePerson=updateConsigneePerson(consigneePerson,consigneePersonDto);
					consigneePersons.add(consigneePerson);
				}else {
					consigneePersonDto.setConsigneePersonUuid(UuidUtil.getUuid());
					ConsigneePerson consigneePerson = mapper.convertToEntity(consigneePersonDto, ConsigneePerson.class);
					consigneePersons.add(consigneePerson);
				}
				
			}
			customerMaster.setConsigneePersons(consigneePersons);
		}
		/*
		 * if(customerMasterDto.getBillingAddress().getAddrsUuid()!=null) { Address
		 * billingAddress =
		 * addressRepo.findByAddrsUuid(customerMasterDto.getBillingAddress().
		 * getAddrsUuid()); billingAddress =
		 * updateAddress(customerMasterDto.getBillingAddress(),billingAddress);
		 * customerMaster.setBillingAddress(billingAddress); }
		 * 
		 * if(customerMasterDto.getShippingAddress().getAddrsUuid()!=null) { Address
		 * shippingAddress =
		 * addressRepo.findByAddrsUuid(customerMasterDto.getShippingAddress().
		 * getAddrsUuid()); shippingAddress =
		 * updateAddress(customerMasterDto.getShippingAddress(),shippingAddress);
		 * customerMaster.setShippingAddress(shippingAddress); }
		 */
		
		customerMasterDao.updateCustomerMaster(customerMaster);
		return "Customer details are updated successfully.";
	}

	
	public ContactPerson updateContactPerson(ContactPerson contactPerson,ContactPersonDto contactPersonDto) {
		contactPerson.setContactPersonName(contactPersonDto.getContactPersonName());
		contactPerson.setDesignation(contactPersonDto.getDesignation());
		contactPerson.setDepartment(contactPersonDto.getDepartment());
		contactPerson.setContactPhone(contactPersonDto.getContactPhone());
		contactPerson.setContactMobile(contactPersonDto.getContactMobile());
		contactPerson.setContactEmail(contactPersonDto.getContactEmail());
		contactPerson.setDateOfBirth(contactPersonDto.getDateOfBirth());
		return contactPerson;
	}
	
	public Address updateAddress(AddressDto addressDto,Address address) {
		address.setStreet(addressDto.getStreet());
		address.setLocality(addressDto.getLocality());
		address.setCity(addressDto.getCity());
		address.setState(addressDto.getState());
		address.setCountry(addressDto.getCountry());
		address.setPincode(addressDto.getPincode());
		address.setAddressType(addressDto.getAddressType());
		address.setAttention(addressDto.getAttention());
		address.setZipCode(addressDto.getZipCode());
		address.setContactPhone(addressDto.getContactPhone());
		return address;
	}
	
	public BusinessUnit updateBusinessUnit(BusinessUnit businessUnit,BusinessUnitDto businessUnitDto,String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		businessUnit.setBookUuid(selfMaster.getBookUuid());
		businessUnit.setContactEmail(businessUnitDto.getContactEmail());
		businessUnit.setContactPhone(businessUnitDto.getContactPhone());
		businessUnit.setGstin(businessUnitDto.getGstin());
		businessUnit.setContactMobile(businessUnitDto.getContactMobile());
		businessUnit.setState(businessUnitDto.getState());
		businessUnit.setUnitName(businessUnitDto.getUnitName());
		businessUnit.setAddress(businessUnitDto.getAddress());
		/*
		 * if(businessUnitDto.getAddress()!=null) {
		 * if(businessUnitDto.getAddress().getAddrsUuid()!=null) { Address address =
		 * addressRepo.findByAddrsUuid(businessUnitDto.getAddress().getAddrsUuid());
		 * businessUnit.setAddress(address); }else {
		 * businessUnitDto.getAddress().setAddrsUuid(UuidUtil.getUuid()); Address
		 * address=mapper.convertToEntity(businessUnitDto.getAddress(),Address.class);
		 * businessUnit.setAddress(address); } }
		 */
		return businessUnit;
	}
	
	
	public ConsigneePerson updateConsigneePerson(ConsigneePerson consigneePerson,ConsigneePersonDto consigneePersonDto) {
		consigneePerson.setConsigneePersonName(consigneePersonDto.getConsigneePersonName());
		consigneePerson.setConsigneePersonAddress(consigneePersonDto.getConsigneePersonAddress());
	
		return consigneePerson;
	}
}
