package com.gloqr.books.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.gloqr.books.constants.*;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.CustomerNotesDto;
import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.PaymentTermsDto;
import com.gloqr.books.dto.SalesPersonDto;
import com.gloqr.books.dto.TermsAndConditionsDto;
import com.gloqr.books.entities.ItemMaster;
//import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.services.BookMasterService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class BookMasterController {
	private static final Logger logger = LogManager.getLogger();

	@Autowired
	RequestParser requestParser;

	@Autowired
	ResponseMaker responseMaker;

	@Autowired
	BookMasterService bookMasterService;

	@PostMapping(UrlMapping.SELF_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveSelfMasterDetails() {

		String tokenUserUuid = requestParser.getUserUUID();

		if (tokenUserUuid != null) {
			return responseMaker.successResponse(bookMasterService.saveSelfMasterDetails(tokenUserUuid),
					HttpStatus.CREATED);
		} else {
			throw new CustomException("Invalid token...smeUuid is null", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(UrlMapping.BOOK_STATUS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<Map<String, Boolean>>> bookStatus() {
		logger.info("Getting gloqr book status about enable or not.");
		String tokenUserUuid = requestParser.getUserUUID();
		Map<String, Boolean> status = new HashMap<String, Boolean>();
		status = bookMasterService.bookStatus(tokenUserUuid);
		return responseMaker.successResponse(status, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.GST_TREATMENT)
	public ResponseEntity<CustomHttpResponse<String>> gstEstimates(
			@Valid @RequestBody GstTreatmentDto gstTreatmentDto) {
		logger.info("Posting Gst treatment record to the database");
		String result = bookMasterService.postGstTreatment(gstTreatmentDto);
		return responseMaker.successResponse(result, HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.GST_TREATMENT)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<GstTreatmentDto>>> getGstTreatment() {
		logger.info("getting gst treatment from backend");
		List<GstTreatmentDto> store = new ArrayList<GstTreatmentDto>();
		store = bookMasterService.getGstTreatment();
		return responseMaker.successResponse(store, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.PAYMENT_TERMS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> savePaymentTerms(
			@Valid @RequestBody PaymentTermsDto paymentTermsDto) {
		logger.info("Initiating savePaymentTerms()");
		String userUuid = requestParser.getUserUUID();
		String result = bookMasterService.savePaymentTerms(paymentTermsDto, userUuid);
		return responseMaker.successResponse(result, HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.PAYMENT_TERMS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<PaymentTermsDto>>> getPaymentTerms() {
		logger.info("getting payment terms.");
		String tokenUserUuid = requestParser.getUserUUID();
		List<PaymentTermsDto> paymentTermsDtoList = new ArrayList<PaymentTermsDto>();
		paymentTermsDtoList = bookMasterService.getPaymentTerms(tokenUserUuid);
		return responseMaker.successResponse(paymentTermsDtoList, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.SALES_PERSON)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveSalesPersonDetails(
			@Valid @RequestBody SalesPersonDto salesPersonDto) {
		logger.info("Initiating saveSalesPersonDetails()");
		String userUuid = requestParser.getUserUUID();
		String result = bookMasterService.saveSalesPerson(salesPersonDto, userUuid);
		return responseMaker.successResponse(result, HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.SALES_PERSON)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<SalesPersonDto>>> getSalesPersonDetails() {
		logger.info("getting sales person details.");
		String tokenUserUuid = requestParser.getUserUUID();
		List<SalesPersonDto> salesPersonDtoList = new ArrayList<SalesPersonDto>();
		salesPersonDtoList = bookMasterService.getSalesPersonDetials(tokenUserUuid);
		return responseMaker.successResponse(salesPersonDtoList, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.CUSTOMER_NOTES)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveCustomerNotes(
			@Valid @RequestBody CustomerNotesDto customerNotesDto) {
		logger.info("Initiating saveCustomerNotes()");
		String userUuid = requestParser.getUserUUID();
		String result = bookMasterService.saveCustomerNotes(customerNotesDto,userUuid);
		return responseMaker.successResponse(result, HttpStatus.CREATED);
	}


	@GetMapping(UrlMapping.CUSTOMER_NOTES)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<CustomerNotesDto>>> getCustomerNotes() {
		logger.info("getting customer notes.");
		String tokenUserUuid = requestParser.getUserUUID();
		List<CustomerNotesDto> customerNotesList = new ArrayList<CustomerNotesDto>();
		customerNotesList = bookMasterService.getCustomerNotes(tokenUserUuid);
		return responseMaker.successResponse(customerNotesList, HttpStatus.OK);
	}
	
	@PostMapping(UrlMapping.TERMS_AND_CONDITIONS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveTermsAndConditions(
			@Valid @RequestBody TermsAndConditionsDto termsAndConditionsDto) {
		logger.info("Initiating saveTermsAndConditions()");
		String userUuid = requestParser.getUserUUID();
		String result = bookMasterService.saveTermsAndConditions(termsAndConditionsDto,userUuid);
		return responseMaker.successResponse(result, HttpStatus.CREATED);
	}
	
	@GetMapping(UrlMapping.TERMS_AND_CONDITIONS)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<TermsAndConditionsDto>>> getTermsAndConditions() {
		logger.info("getting terms and conditions.");
		String tokenUserUuid = requestParser.getUserUUID();
		List<TermsAndConditionsDto> termsAndConditionsDtos = new ArrayList<TermsAndConditionsDto>();
		termsAndConditionsDtos = bookMasterService.getTermsAndConditions(tokenUserUuid);
		return responseMaker.successResponse(termsAndConditionsDtos, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_BOOK_UUID)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<Map<String, String>>> getBookUuid() {
		logger.info("Getting gloqr book status about enable or not.");
		String tokenUserUuid = requestParser.getUserUUID();
		Map<String, String> bookUuid = new HashMap<String, String>();
		bookUuid = bookMasterService.getBookUuid(tokenUserUuid);
		return responseMaker.successResponse(bookUuid, HttpStatus.OK);
	}

}
