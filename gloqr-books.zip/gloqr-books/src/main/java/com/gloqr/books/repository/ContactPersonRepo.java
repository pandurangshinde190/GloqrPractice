package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.ContactPerson;

public interface ContactPersonRepo extends JpaRepository<ContactPerson, Long>{

	ContactPerson findByContactPersonUuid(String contactPersonUuid);
}
