package com.gloqr.books.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.books.dao.ItemMasterDao;
import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.LedgerDto;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.AccountMaster;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.Ledger;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TaxMaster;
import com.gloqr.books.entities.UOM;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.AccountMasterRepo;
import com.gloqr.books.repository.ItemMasterRepo;
import com.gloqr.books.repository.SelfMasterRepo;
import com.gloqr.books.repository.TaxMasterRepo;
import com.gloqr.books.repository.UOMMasterRepo;
import com.gloqr.books.util.UuidUtil;

@Service
public class ItemMasterServiceImpl implements ItemMasterService {
	@Autowired
	Mapper mapper;

	@Autowired
	ItemMasterDao itemMasterdao;

	@Autowired
	AccountMasterRepo accountMasterRepo;

	@Autowired
	UOMMasterRepo uomMasterRepo;

	@Autowired
	TaxMasterRepo taxMasterRepo;

	@Autowired
	SelfMasterRepo selfMasterRepo;

	
	@Autowired
	ItemMasterRepo itemMasterRepo;
	

	@Override
	public String saveTaxMasterDetails(TaxMasterDto taxMasterDto) {
		taxMasterDto.setTaxMasterUuid(UuidUtil.getUuid(taxMasterDto.getName()));
		TaxMaster taxMaster = mapper.convertToEntity(taxMasterDto, TaxMaster.class);
		return itemMasterdao.saveTaxMaster(taxMaster);
	}

	@Override
	public String saveUomMasterDetails(UOMMasterDto uomMasterDto) {
		uomMasterDto.setUomUuid(UuidUtil.getUuid(uomMasterDto.getName()));
		UOM uomMaster = mapper.convertToEntity(uomMasterDto, UOM.class);
		return itemMasterdao.saveUomMaster(uomMaster);
	}

	@Override
	public String saveAccountMasterDetails(AccountMasterDto accountMasterDto) {
		accountMasterDto.setAccountMasterUuid(UuidUtil.getUuid(accountMasterDto.getAccountGroupName()));
		
		AccountMaster accountMaster = mapper.convertToEntity(accountMasterDto, AccountMaster.class);

		if(accountMasterDto.getParentGroupUuid()!=null) {
			AccountMaster parentAccount = accountMasterRepo.findByAccountMasterUuid(accountMasterDto.getParentGroupUuid());
			accountMaster.setParentGroup(parentAccount);
		}
		return itemMasterdao.saveAccountMaster(accountMaster);	

	}

	@Override
	public String saveLedger(LedgerDto ledgerDto) {
		ledgerDto.setLedgerUuid(UuidUtil.getUuid(ledgerDto.getLedgerName()));
		Ledger ledger = mapper.convertToEntity(ledgerDto, Ledger.class);
		if(ledgerDto.getAccountMasterUuid()!=null) {
			AccountMaster accountMaster = accountMasterRepo.findByAccountMasterUuid(ledgerDto.getAccountMasterUuid());
			ledger.setAccountMaster(accountMaster);
		}
		return itemMasterdao.saveLedgerMaster(ledger);

	}

	// GET API'S
	@Override

	public String addItemMaster(ItemMasterDto itemMasterDto,String uuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		itemMasterDto.setBookUuid(selfMaster.getBookUuid());

		List<ItemMaster> itemMasters = itemMasterRepo.findByBookUuid(selfMaster.getBookUuid());
		if(itemMasters!=null) {
			for(ItemMaster item:itemMasters) {
				if(item.getName().equalsIgnoreCase(itemMasterDto.getName())) {
					throw new CustomException("Item is already present.: ",HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
		}
		
		itemMasterDto.setItemMasterUuid(UuidUtil.getUuid(itemMasterDto.getName()));
		ItemMaster itemMaster = mapper.convertToEntity(itemMasterDto, ItemMaster.class);
		AccountMaster salesAccount = accountMasterRepo.findByAccountMasterUuid(itemMasterDto.getSalesAccountUuid());
		AccountMaster purchaseAccount = accountMasterRepo
				.findByAccountMasterUuid(itemMasterDto.getPurchaseAccountUuid());
		UOM uom = uomMasterRepo.findByuomUuid(itemMasterDto.getUomUuid());
		TaxMaster taxMaster = taxMasterRepo.findByTaxMasterUuid(itemMasterDto.getTaxMasterUuid());
		itemMaster.setUom(uom);
		itemMaster.setTaxMaster(taxMaster);
		itemMaster.setSalesAccount(salesAccount);
		itemMaster.setPurchaseAccount(purchaseAccount);
		return itemMasterdao.saveItemMaster(itemMaster);
	}

	@Override
	public List<TaxMasterDto> getTaxMaster() {
		return itemMasterdao.getTaxMaster();
	}

	@Override
	public List<UOMMasterDto> getUomMaster() {
		return itemMasterdao.getUomMaster();
	}

	@Override
	public List<AccountMasterDto> getAccountMaster() {
		return itemMasterdao.getAccountMaster();
	}

	@Override
	public List<LedgerDto> getLedger() {
		return itemMasterdao.getLedgerMaster();
	}

	@Override
	public ItemMasterVO getItem(String itemUuid) {
		return itemMasterdao.getItem(itemUuid);

	}

	@Override
	public List<ItemMasterVO> getItemMaster(String uuid,int page) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(uuid);
		return itemMasterdao.getItemMaster(selfMaster.getBookUuid(),page);
	}

	@Override
	public String updateItemMaster(ItemMasterDto itemMasterDto) {

		if (itemMasterDto.getItemMasterUuid() != null) {
			ItemMaster itemMaster = itemMasterdao.getItemMasterByUuid(itemMasterDto.getItemMasterUuid());

			if(itemMasterDto.getSalesAccountUuid()!=null) {
				AccountMaster salesAccount=accountMasterRepo.findByAccountMasterUuid(itemMasterDto.getSalesAccountUuid());
				itemMaster.setSalesAccount(salesAccount);
			}
			if(itemMasterDto.getPurchaseAccountUuid()!=null) {
				AccountMaster purchaseAccount = accountMasterRepo.findByAccountMasterUuid(itemMasterDto.getPurchaseAccountUuid());
				itemMaster.setPurchaseAccount(purchaseAccount);

			}
			if(itemMasterDto.getUomUuid()!=null) {
				UOM uom=uomMasterRepo.findByuomUuid(itemMasterDto.getUomUuid());
				itemMaster.setUom(uom);
			}
			if(itemMasterDto.getTaxMasterUuid()!=null) {
				TaxMaster taxMaster = taxMasterRepo.findByTaxMasterUuid(itemMasterDto.getTaxMasterUuid());
				itemMaster.setTaxMaster(taxMaster);
			}
			itemMaster.setType(itemMasterDto.getType());
			itemMaster.setName(itemMasterDto.getName());
			itemMaster.setHsnSacCode(itemMasterDto.getHsnSacCode());
			itemMaster.setCgstTax(itemMasterDto.getCgstTax());
			itemMaster.setSgstTax(itemMasterDto.getSgstTax());
			itemMaster.setIgstTax(itemMasterDto.getIgstTax());
			itemMaster.setSellingPrice(itemMasterDto.getSellingPrice());
			itemMaster.setCostPrice(itemMasterDto.getCostPrice());
			itemMaster.setSellingDescription(itemMasterDto.getSellingDescription());
			itemMaster.setPurchaseDescription(itemMasterDto.getPurchaseDescription());
			itemMaster.setMinStock(itemMasterDto.getMinStock());
			itemMaster.setMaxStock(itemMasterDto.getMaxStock());
			itemMaster.setTaxPreferance(itemMasterDto.getTaxPreferance());

			
			itemMasterdao.saveItemMaster(itemMaster);

		}

		
		return "item master updated successfully" ;
	}

}
