package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "b_files")
public class Files extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="files_id")
	private Long filesId;

	@Column(name = "files_uuid", nullable = false, updatable = false)
	private String filesUuid;
	
	@Column(name ="name")
	private String name;
	
	@Column(name = "type")
	private String type;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "size")
	private long size;
	
	@Column(name = "reference_id")
	private String referenceId;
	
	@Column(name = "is_active")
	private boolean isActive;
	
	@Column(name = "sales_order_uuid")
	private String salesOrderUuid;
	
	

	public Files() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Files( String filesUuid,String name, String type, String location, long size,boolean isActive) {
		super();
		this.filesUuid = filesUuid;
		this.name=name;
		this.type = type;
		this.location = location;
		this.size = size;
		this.isActive = isActive;
	}

	public Long getFilesId() {
		return filesId;
	}

	public void setFilesId(Long filesId) {
		this.filesId = filesId;
	}

	public String getFilesUuid() {
		return filesUuid;
	}

	public void setFilesUuid(String filesUuid) {
		this.filesUuid = filesUuid;
	}
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getSalesOrderUuid() {
		return salesOrderUuid;
	}

	public void setSalesOrderUuid(String salesOrderUuid) {
		this.salesOrderUuid = salesOrderUuid;
	}


	
	
}
