package com.gloqr.books.dto;


public class SalesPersonDto {

	private String salesPersonUuid;

	private String salesPersonName;

	private String salesPersonEmail;
	
	private String bookUuid;

	public String getSalesPersonUuid() {
		return salesPersonUuid;
	}

	public void setSalesPersonUuid(String salesPersonUuid) {
		this.salesPersonUuid = salesPersonUuid;
	}

	public String getSalesPersonName() {
		return salesPersonName;
	}

	public void setSalesPersonName(String salesPersonName) {
		this.salesPersonName = salesPersonName;
	}

	public String getSalesPersonEmail() {
		return salesPersonEmail;
	}

	public void setSalesPersonEmail(String salesPersonEmail) {
		this.salesPersonEmail = salesPersonEmail;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

}
