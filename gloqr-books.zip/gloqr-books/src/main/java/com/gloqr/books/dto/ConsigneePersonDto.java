package com.gloqr.books.dto;



public class ConsigneePersonDto {

	private String consigneePersonUuid;

	private String consigneePersonName;

	private String consigneePersonAddress;
	
	private Boolean isDefault;

	public String getConsigneePersonUuid() {
		return consigneePersonUuid;
	}

	public void setConsigneePersonUuid(String consigneePersonUuid) {
		this.consigneePersonUuid = consigneePersonUuid;
	}

	public String getConsigneePersonName() {
		return consigneePersonName;
	}

	public void setConsigneePersonName(String consigneePersonName) {
		this.consigneePersonName = consigneePersonName;
	}

	public String getConsigneePersonAddress() {
		return consigneePersonAddress;
	}

	public void setConsigneePersonAddress(String consigneePersonAddress) {
		this.consigneePersonAddress = consigneePersonAddress;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	
	
	
}
