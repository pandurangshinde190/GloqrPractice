package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.UOM;

public interface UOMMasterRepo extends JpaRepository<UOM,Long>{
	
	UOM findByuomUuid(String uomUuid);

}
