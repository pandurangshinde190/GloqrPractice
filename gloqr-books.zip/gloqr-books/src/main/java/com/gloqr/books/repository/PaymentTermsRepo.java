package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.PaymentTerms;

public interface PaymentTermsRepo extends JpaRepository<PaymentTerms, Long> {

	PaymentTerms findByPaymentTermsUuid(String paymentTermsUuid);
	
	List<PaymentTerms> findByBookUuid(String bookUuid);
}
