
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity

@Table(name = "b_business_unit")
public class BusinessUnit extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "business_unit_id")
	private Long businessUnitId;

	@Column(name = "business_unit_uuid", nullable = false, updatable = false)
	private String businessUnitUuid;

	@Column(name = "gstin")
	private String gstin;

	@Column(name = "unit_name")
	private String unitName;

	/*
	 * @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 * 
	 * @JoinColumn(name = "address_id") private Address address;
	 */
	@Column(name = "is_default")
	private Boolean isDefault;
	

	@Column(name = "address")
	private String address;
	
	@Column(name = "state")
	private String state;

	@Column(name = "phone")
	private String contactPhone;

	@Column(name = "mobile")
	private String contactMobile;

	@Column(name = "email")
	private String contactEmail;
	
	@Column(name = "book_uuid")
	private String bookUuid;
	
//	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
//	@JoinColumn(name="customer_master_uuid")
//	private String customerMUuid;

	public Long getBusinessUnitId() {
		return businessUnitId;
	}

	public void setBusinessUnitId(Long businessUnitId) {
		this.businessUnitId = businessUnitId;
	}

	public String getBusinessUnitUuid() {
		return businessUnitUuid;
	}

	public void setBusinessUnitUuid(String businessUnitUuid) {
		this.businessUnitUuid = businessUnitUuid;
	}

	

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	/*
	 * public Address getAddress() { return address; }
	 * 
	 * public void setAddress(Address address) { this.address = address; }
	 */

	public String getState() {
		return state;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}


	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

//	public String getCustomerMUuid() {
//		return customerMUuid;
//	}
//
//	public void setCustomerMUuid(String customerMUuid) {
//		this.customerMUuid = customerMUuid;
//	}

}
