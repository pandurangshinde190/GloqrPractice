package com.gloqr.books.services;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.entities.Files;

public interface FileService {

	public List<Files> sendFilesToContentServer(List<MultipartFile> files, String fileLocation) throws IOException;

}
