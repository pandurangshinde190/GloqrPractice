package com.gloqr.books.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.entities.CustomerNotes;
import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SalesPerson;
//import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TermsAndConditions;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.CustomerNotesRepo;
import com.gloqr.books.repository.GstTreatmentRepo;
import com.gloqr.books.repository.ItemMasterRepo;
import com.gloqr.books.repository.PaymentTermsRepo;
import com.gloqr.books.repository.SalesPersonRepo;
import com.gloqr.books.repository.SelfMasterRepo;
import com.gloqr.books.repository.TermsAndConditionsRepo;

@Repository
public class BookMasterDaoImpl implements BookMasterDao {

	@Autowired
	SelfMasterRepo selfMasterRepo;

	@Autowired
	GstTreatmentRepo gstTreatmentRepo;

	@Autowired
	Mapper mapper;
	
	@Autowired
	PaymentTermsRepo paymentTermsRepo;
	
	@Autowired
	SalesPersonRepo salesPersonRepo;

	@Autowired
	CustomerNotesRepo customerNotesRepo;

	@Autowired
	TermsAndConditionsRepo termsAndConditionsRepo;
	
	@Override
	public void saveSelfMasterDetails(SelfMaster selfMaster) {
		try {
			selfMasterRepo.save(selfMaster);
		} catch (Exception e) {
			throw new CustomException("Exception in saveSelfMasterDetails Method.  message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

	}

	@Override
	public Map<String, Boolean> getBookStatus(String userUuid) {
		boolean statusResult = selfMasterRepo.existsByUuid(userUuid);
		Map<String, Boolean> status = new HashMap<String, Boolean>();
		status.put("Status", statusResult);
		return status;
	}

	@Override
	public String saveGstTreatment(GstTreatment gstTreatment) {
		try {
			gstTreatmentRepo.save(gstTreatment);
		} catch (Exception e) {
			throw new CustomException("Exception in saveGstTreatment Method.  message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}

		return "Gst Treatment Details are saved successfully";
	}

	@Override
	public List<GstTreatmentDto> getGstTreatment() {
		List<GstTreatment> gstTreatment = gstTreatmentRepo.findAll();
		List<GstTreatmentDto> gstTDto = new ArrayList<GstTreatmentDto>();
		for (GstTreatment gst : gstTreatment) {
			GstTreatmentDto gstTreatmentDto = mapper.convertToDto(gst, GstTreatmentDto.class);
			gstTDto.add(gstTreatmentDto);
		}
		return gstTDto;
	}

	@Override
	public void savePaymentTermsDetails(PaymentTerms paymentTerms) {
		try {
			paymentTermsRepo.save(paymentTerms);
		}catch(Exception e) {
			throw new CustomException("Exception occured while saving payment terms. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void saveSalesPersonDetails(SalesPerson salesPerson) {
		try {
			salesPersonRepo.save(salesPerson);
		}catch(Exception e) {
			throw new CustomException("Exception occured while saving sales person details. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
		
	}

	@Override
	public void saveCustomerNotes(CustomerNotes customerNotes) {
		try {
			customerNotesRepo.save(customerNotes);
		}catch(Exception e) {
			throw new CustomException("Exception occured while saving customer notes. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public void saveTermsAndConditions(TermsAndConditions termsAndConditions) {
		try {
			termsAndConditionsRepo.save(termsAndConditions);
		}catch(Exception e) {
			throw new CustomException("Exception occured while saving terms and conditions. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR, e);
		}
	}

	@Override
	public Map<String, String> getBookUuid(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		Map<String,String> bookUuid=new HashMap<String, String>();
		bookUuid.put("bookUuid", selfMaster.getBookUuid());
		return bookUuid;
	}
	
	

}
