
package com.gloqr.books.entities;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.ContainedIn;

import com.gloqr.books.constants.CustomerType;

@Entity
@Table(name = "b_customer_master")
public class CustomerMaster extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customer_m_id")
	private Long customerMId;

	@Column(name = "customer_master_uuid", nullable = false, updatable = false)
	private String customerMUuid;
	
	@Column(name = "is_default")
	private Boolean isDefault;

	/*
	 * @Column(name = "company_name") private String companyName;
	 * 
	 * @Column(name = "designation") private String designation;
	 * 
	 * @Column(name = "department") private String department;
	 */

	/*
	 * @Column(name = "gstin") private String gstin;
	 */

	@Column(name = "phone")
	private String contactPhone;

	@Column(name = "mobile")
	private String contactMobile;

	@Column(name = "email")
	private String contactEmail;

	@Column(name = "website")
	private String website;

	/*
	 * @Column(name = "place_of_supply") private String placeOfSupply;
	 */

	@Column(name = "vendor_code")
	private String vendorCode;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "gst_treatment_id")
	private GstTreatment gstTreatment;

	@Column(name = "opening_balance")
	private double openingBalance;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "payment_terms_id")
	private PaymentTerms paymentTerms;

	@Column(name = "credit_days")
	private int creditDays;

	@Column(name = "customer_type")
	@Enumerated(EnumType.STRING)
	private CustomerType customerType;



	@Column(name = "book_uuid")
	private String bookUuid;

	@Column(name = "customer_name")
	private String customerName;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_m_id",referencedColumnName = "customer_m_id")
	private List<ContactPerson> contactPersons;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_m_id",referencedColumnName = "customer_m_id")
	private List<BusinessUnit> businessUnits;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_m_id",referencedColumnName = "customer_m_id")
	private List<ConsigneePerson> consigneePersons;
	
	

	public Long getCustomerMId() {
		return customerMId;
	}

	public void setCustomerMId(Long customerMId) {
		this.customerMId = customerMId;
	}

	public String getCustomerMUuid() {
		return customerMUuid;
	}

	public void setCustomerMUuid(String customerMUuid) {
		this.customerMUuid = customerMUuid;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public GstTreatment getGstTreatment() {
		return gstTreatment;
	}

	public void setGstTreatment(GstTreatment gstTreatment) {
		this.gstTreatment = gstTreatment;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public PaymentTerms getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(PaymentTerms paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public int getCreditDays() {
		return creditDays;
	}

	public void setCreditDays(int creditDays) {
		this.creditDays = creditDays;
	}

	public CustomerType getCustomerType() {
		return customerType;
	}

	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}


	/*
	 * public String getPlaceOfSupply() { return placeOfSupply; }
	 * 
	 * public void setPlaceOfSupply(String placeOfSupply) { this.placeOfSupply =
	 * placeOfSupply; }
	 */

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}


	public List<ContactPerson> getContactPersons() {
		return contactPersons;
	}

	public void setContactPersons(List<ContactPerson> contactPersons) {
		this.contactPersons = contactPersons;
	}

	public List<BusinessUnit> getBusinessUnits() {
		return businessUnits;
	}

	public void setBusinessUnits(List<BusinessUnit> businessUnits) {
		this.businessUnits = businessUnits;
	}

	public List<ConsigneePerson> getConsigneePersons() {
		return consigneePersons;
	}

	public void setConsigneePersons(List<ConsigneePerson> consigneePersons) {
		this.consigneePersons = consigneePersons;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

}
