
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "b_consignee_person")
public class ConsigneePerson extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "consignee_person_id")
	private Long consigneePersonId;

	@Column(name = "consignee_person_uuid", nullable = false, updatable = false)
	private String consigneePersonUuid;

	@Column(name = "is_default")
	private Boolean isDefault;
	
	@Column(name = "consignee_person_name")
	private String consigneePersonName;

	/*
	 * @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 * 
	 * @JoinColumn(name = "address_id") private Address address;
	 */

	@Column(name = "consignee_person_address")
	private String consigneePersonAddress;
	
	public Long getConsigneePersonId() {
		return consigneePersonId;
	}

	public void setConsigneePersonId(Long consigneePersonId) {
		this.consigneePersonId = consigneePersonId;
	}

	public String getConsigneePersonUuid() {
		return consigneePersonUuid;
	}

	public void setConsigneePersonUuid(String consigneePersonUuid) {
		this.consigneePersonUuid = consigneePersonUuid;
	}

	public String getConsigneePersonName() {
		return consigneePersonName;
	}

	public void setConsigneePersonName(String consigneePersonName) {
		this.consigneePersonName = consigneePersonName;
	}

	public String getConsigneePersonAddress() {
		return consigneePersonAddress;
	}

	public void setConsigneePersonAddress(String consigneePersonAddress) {
		this.consigneePersonAddress = consigneePersonAddress;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	

}
