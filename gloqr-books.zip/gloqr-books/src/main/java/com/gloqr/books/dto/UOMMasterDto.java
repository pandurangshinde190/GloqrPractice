package com.gloqr.books.dto;


public class UOMMasterDto {

	private String uomUuid;

	private String name;

	private String baseUnit;

	private String conversion;

	public String getUomUuid() {
		return uomUuid;
	}

	public void setUomUuid(String uomUuid) {
		this.uomUuid = uomUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBaseUnit() {
		return baseUnit;
	}

	public void setBaseUnit(String baseUnit) {
		this.baseUnit = baseUnit;
	}

	public String getConversion() {
		return conversion;
	}

	public void setConversion(String conversion) {
		this.conversion = conversion;
	}
	
	

}
