package com.gloqr.books.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.books.constants.Constants;
import com.gloqr.books.constants.UrlMapping;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.ItemListDto;
import com.gloqr.books.services.SearchService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;
;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
public class SearchController {
	
	@Autowired
	RequestParser requestParser;

	@Autowired
	ResponseMaker responseMaker;
	
	@Autowired
	SearchService searchService;
	
	@GetMapping(UrlMapping.ITEM_SEARCH_SUGGEST)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ItemListDto>>> getAutoSuggestedResults(
			@RequestParam(value = "searchText") String searchText,
			@RequestParam(value = "maxResult", defaultValue = "10") int maxResult) {
		String uuid = requestParser.getUserUUID();
		List<ItemListDto> searchedItems = searchService.getSearchItemSuggestions(searchText, maxResult,uuid);
		return responseMaker.successResponse(searchedItems, HttpStatus.OK);
	}


}
