package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.Address;

public interface AddressRepo extends JpaRepository<Address,Long>{

	Address findByAddrsUuid(String addrsUuid);
}
