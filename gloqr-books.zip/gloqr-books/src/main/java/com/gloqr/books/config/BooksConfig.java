package com.gloqr.books.config;

import javax.annotation.Resource;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.gloqr.books.endpoints.ContentServerEndpoint;
import com.gloqr.books.endpoints.SmeEndpoint;



@Configuration
@PropertySource(value = { "file:${location}/gloqr-books.properties" })
public class BooksConfig {

	@Resource
	private Environment environment;

	@Bean
	public ClientConfig clientConfig() {
		ClientConfig configuration = new ClientConfig();
		configuration.property(ClientProperties.CONNECT_TIMEOUT, 10000);
		configuration.property(ClientProperties.READ_TIMEOUT, 60000);

		return configuration;
	}

	

	
	@Bean
	public SmeEndpoint smeConfig() {
		Client client = ClientBuilder.newClient(clientConfig());
		String endpoint = environment.getRequiredProperty("sme.endpoint");
		String userDetailsPath = environment.getRequiredProperty("sme.detail");
		return new SmeEndpoint(client, endpoint, userDetailsPath);
	}

	@Bean
	public TemplateCommonUrl templatePropertiesConfig() {

		String websiteUrl = environment.getRequiredProperty("website.url");
		String contentServerUrl = environment.getRequiredProperty("content.server.cdn.path");

		return new TemplateCommonUrl(websiteUrl, contentServerUrl);
	}

	@Bean(name = "taskExecutor")
	public TaskExecutor workExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setThreadNamePrefix("Async-Thread");

		threadPoolTaskExecutor.setCorePoolSize(5);
		threadPoolTaskExecutor.setMaxPoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(600);
		threadPoolTaskExecutor.afterPropertiesSet();

		return threadPoolTaskExecutor;
	}
	
	@Bean
	public ContentServerEndpoint contentConfiguration() {
		Client client = ClientBuilder.newBuilder().register(MultiPartFeature.class).build();

		String endPoint = environment.getRequiredProperty("contentserver.endpoint");
		String uploadFiles = environment.getRequiredProperty("uploadsfiles.endpoint.path");
		String deleteFiles = environment.getRequiredProperty("deletefiles.endpoint.path");
		return new ContentServerEndpoint(client, endPoint, uploadFiles, deleteFiles);
	}
}
