package com.gloqr.books.dto;

import javax.persistence.Column;

import com.gloqr.books.constants.ItemType;

public class ItemListDto {
	
	private String itemMasterUuid;

	private String name;

	private double costPrice;
	
	private double cgstTax;

	private double sgstTax;

	private double igstTax;
	
	private ItemType type;
	
	private String hsnSacCode;
	
	private double sellingPrice;
	
	private UOMMasterDto uomMasterDto;
	
	public ItemListDto() {
		super();
	}

	public ItemListDto(String itemMasterUuid, String name) {
		super();
		this.itemMasterUuid = itemMasterUuid;
		this.name = name;
	}

	public String getItemMasterUuid() {
		return itemMasterUuid;
	}

	public void setItemMasterUuid(String itemMasterUuid) {
		this.itemMasterUuid = itemMasterUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}

	public double getCgstTax() {
		return cgstTax;
	}

	public void setCgstTax(double cgstTax) {
		this.cgstTax = cgstTax;
	}

	public double getSgstTax() {
		return sgstTax;
	}

	public void setSgstTax(double sgstTax) {
		this.sgstTax = sgstTax;
	}

	public double getIgstTax() {
		return igstTax;
	}

	public void setIgstTax(double igstTax) {
		this.igstTax = igstTax;
	}

	public ItemType getType() {
		return type;
	}

	public void setType(ItemType type) {
		this.type = type;
	}

	public String getHsnSacCode() {
		return hsnSacCode;
	}

	public void setHsnSacCode(String hsnSacCode) {
		this.hsnSacCode = hsnSacCode;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public UOMMasterDto getUomMasterDto() {
		return uomMasterDto;
	}

	public void setUomMasterDto(UOMMasterDto uomMasterDto) {
		this.uomMasterDto = uomMasterDto;
	}

	

}
