
  package com.gloqr.books.repository;
  
  import org.springframework.data.jpa.repository.JpaRepository;
  
  import com.gloqr.books.entities.GstTreatment;
  
  public interface GstTreatmentRepo extends JpaRepository<GstTreatment, Long>{
	  
	  GstTreatment findByGstTreatmentUuid(String gstTreatmentUuid);
  
  }
 