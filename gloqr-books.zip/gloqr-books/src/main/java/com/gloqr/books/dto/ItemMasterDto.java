package com.gloqr.books.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.gloqr.books.constants.ItemType;
import com.gloqr.books.constants.TaxPreference;

@JsonInclude(Include.NON_NULL)
public class ItemMasterDto {

	private String itemMasterUuid;
	


	private ItemType type;


	private String name;


	private String hsnSacCode;

	private double cgstTax;

	private double sgstTax;

	private double igstTax;

	private double sellingPrice;

	private double costPrice;

	private String sellingDescription;

	private String purchaseDescription;

	private int minStock;

	private int maxStock;

	private TaxPreference taxPreferance;

	private String salesAccountUuid;
	
	private String purchaseAccountUuid;
	
	private String uomUuid;
	
	private String taxMasterUuid;
	
	private String bookUuid;


	public String getItemMasterUuid() {
		return itemMasterUuid;
	}

	public void setItemMasterUuid(String itemMasterUuid) {
		this.itemMasterUuid = itemMasterUuid;
	}
	




	public ItemType getType() {
		return type;
	}

	public void setType(ItemType type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getHsnSacCode() {
		return hsnSacCode;
	}

	public void setHsnSacCode(String hsnSacCode) {
		this.hsnSacCode = hsnSacCode;
	}

	public double getCgstTax() {
		return cgstTax;
	}

	public void setCgstTax(double cgstTax) {
		this.cgstTax = cgstTax;
	}

	public double getSgstTax() {
		return sgstTax;
	}

	public void setSgstTax(double sgstTax) {
		this.sgstTax = sgstTax;
	}

	public double getIgstTax() {
		return igstTax;
	}

	public void setIgstTax(double igstTax) {
		this.igstTax = igstTax;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public double getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}

	public String getSellingDescription() {
		return sellingDescription;
	}

	public void setSellingDescription(String sellingDescription) {
		this.sellingDescription = sellingDescription;
	}

	public String getPurchaseDescription() {
		return purchaseDescription;
	}

	public void setPurchaseDescription(String purchaseDescription) {
		this.purchaseDescription = purchaseDescription;
	}

	public int getMinStock() {
		return minStock;
	}

	public void setMinStock(int minStock) {
		this.minStock = minStock;
	}

	public int getMaxStock() {
		return maxStock;
	}

	public void setMaxStock(int maxStock) {
		this.maxStock = maxStock;
	}

	public TaxPreference getTaxPreferance() {
		return taxPreferance;
	}

	public void setTaxPreferance(TaxPreference taxPreferance) {
		this.taxPreferance = taxPreferance;
	}

	
	public String getSalesAccountUuid() {
		return salesAccountUuid;
	}

	public void setSalesAccountUuid(String salesAccountUuid) {
		this.salesAccountUuid = salesAccountUuid;
	}

	public String getPurchaseAccountUuid() {
		return purchaseAccountUuid;
	}

	public void setPurchaseAccountUuid(String purchaseAccountUuid) {
		this.purchaseAccountUuid = purchaseAccountUuid;
	}

	public String getUomUuid() {
		return uomUuid;
	}

	public void setUomUuid(String uomUuid) {
		this.uomUuid = uomUuid;
	}

	public String getTaxMasterUuid() {
		return taxMasterUuid;
	}

	public void setTaxMasterUuid(String taxMasterUuid) {
		this.taxMasterUuid = taxMasterUuid;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}
}
