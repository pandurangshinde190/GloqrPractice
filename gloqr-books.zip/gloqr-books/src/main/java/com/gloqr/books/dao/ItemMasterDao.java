package com.gloqr.books.dao;

import java.util.List;

import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.LedgerDto;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.AccountMaster;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.Ledger;
import com.gloqr.books.entities.TaxMaster;
import com.gloqr.books.entities.UOM;

public interface ItemMasterDao {
	
	String saveItemMaster(ItemMaster itemMaster);
	
	List<TaxMasterDto> getTaxMaster();
	
	List<UOMMasterDto> getUomMaster();
	
	List<AccountMasterDto> getAccountMaster();
	
	String saveTaxMaster(TaxMaster taxMaster);
	
	String saveUomMaster(UOM uom);
	
	String saveAccountMaster(AccountMaster accountMaster);
	
	String saveLedgerMaster(Ledger ledger);
	
	List<LedgerDto> getLedgerMaster();
	
	ItemMasterVO getItem(String itemUuid);
	
	List<ItemMasterVO> getItemMaster(String bookUuid,int page);
	
	ItemMaster getItemMasterByUuid(String itemUuid);


}
