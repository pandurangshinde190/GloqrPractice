package com.gloqr.books.config;

public class TemplateCommonUrl {

	public static final String BASE_PATH = "/gloqr-platform" + "/images/";

	private String websiteUrl;
	private String contentServerUrl;

	private String gloqrLogoPath = BASE_PATH + "gloqr-logo.png";
	private String fbLogoPath = BASE_PATH + "facebook-logo.png";
	private String linkedinLogoPath = BASE_PATH + "linkedin-logo.png";
	private String twitterLogoPath = BASE_PATH + "twitter-logo.png";
	private String instaLogoPath = BASE_PATH + "youtube-logo.png";
	private String ytLogoPath = BASE_PATH + "instagram-logo.png";

	public TemplateCommonUrl(String websiteUrl, String contentServerUrl) {
		super();
		this.websiteUrl = websiteUrl;
		this.contentServerUrl = contentServerUrl;
	}

	public String getWebsiteUrl() {
		return websiteUrl;
	}

	public String getContentServerUrl() {
		return contentServerUrl;
	}

	public String getGloqrLogoPath() {
		return gloqrLogoPath;
	}

	public String getFbLogoPath() {
		return fbLogoPath;
	}

	public String getLinkedinLogoPath() {
		return linkedinLogoPath;
	}

	public String getTwitterLogoPath() {
		return twitterLogoPath;
	}

	public String getInstaLogoPath() {
		return instaLogoPath;
	}

	public String getYtLogoPath() {
		return ytLogoPath;
	}
}
