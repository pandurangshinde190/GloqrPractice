package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.entities.BusinessUnit;

public interface BusinessUnitRepo extends JpaRepository<BusinessUnit, Long>{

	BusinessUnit findByBusinessUnitUuid(String businessUnitUuid);
	
	List<BusinessUnit> findByBookUuid(String bookUuid);
	
	//BusinessUnit findByCustomerMUuid(String customerMUuid);
}
