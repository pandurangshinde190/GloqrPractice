package com.gloqr.books.services;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.dto.ConsigneePersonListDto;
import com.gloqr.books.dto.ContactPersonListDto;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.SalesOrderVO;

public interface SalesOrderService {

	String saveSalesOrderDetails(SalesOrderDto salesOrderDto,String suuid);
	
	List<SalesOrderVO> getSalesOrderDetails(String uuid,int page);
	
	SalesOrderVO getSalesOrder(String salesOrderUuid);
	
	String updateSalesOrder(SalesOrderDto salesOrderDto);
	
	List<BusinessUnitListDto> getBusinessUnitForCustomer(String customerMUuid);
	
	List<ContactPersonListDto> getContactPersonForCustomer(String customerMUuid);
	
	List<ConsigneePersonListDto> getConsigneePersonForCustomer(String customerMUuid);
	
	Map<String,String> getSelfMasterState(String userUuid);
	
}
