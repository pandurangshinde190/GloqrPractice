package com.gloqr.books.dao;

import java.util.List;

import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.SalesOrderVO;
import com.gloqr.books.entities.Files;
import com.gloqr.books.entities.SalesOrder;

public interface SalesOrderDao {

	String saveSalesOrderDetails(SalesOrder salesOrder);
	
	List<SalesOrderVO> getSalesOrderDetails(String bookUuid,int page);
	
	SalesOrderVO getSalesOrder(String salesOrderUuid);
	
	String updateSalesOrder(SalesOrder salesOrder);
	
	void updateFiles(List<Files> fileList);
	
}
