package com.gloqr.books.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "b_sales_order")
public class SalesOrder extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sales_order_id")
	private Long salesOrderId;

	@Column(name = "sales_order_uuid", nullable = false, updatable = false)
	private String salesOrderUuid;

	@Column(name = "book_uuid")
	private String bookUuid;

	@OneToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_m_id")
	private CustomerMaster customerMaster;
	
	@OneToOne(cascade =CascadeType.DETACH,fetch=FetchType.LAZY)
	@JoinColumn(name="business_unit_id")
	private BusinessUnit businessUnit;
	
	@OneToOne(cascade=CascadeType.DETACH,fetch=FetchType.LAZY)
	@JoinColumn(name="contact_person_id")
	private ContactPerson contactPerson;
	
	@OneToOne(cascade=CascadeType.DETACH,fetch=FetchType.LAZY)
	@JoinColumn(name="consignee_person_id")
	private ConsigneePerson consigneePerson;
	
	@Column(name = "sales_order_number")
	private String salesOrderNumber;

	@Column(name = "reference_number")
	private String referenceNumber;

	@Column(name = "sales_order_date")
	private Date salesOrderDate;

	@Column(name = "expected_shipment_date")
	private Date expectedShipmentDate;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "payment_terms_id")
	private PaymentTerms paymentTerms;

	@Column(name = "delivery_method")
	private String deliveryMethod;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "sales_person_id")
	private SalesPerson salesPerson;

//	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name = "order_item_id")
//	private OrderItem orderItem;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "b_sales_order_join_order_item", joinColumns = {
			@JoinColumn(name = "sales_order_id", referencedColumnName = "sales_order_id") }, inverseJoinColumns = {
					@JoinColumn(name = "order_item_id", referencedColumnName = "order_item_id") })
	private List<OrderItem> orderItems;

	/*
	 * @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 * 
	 * @JoinColumn(name = "customer_notes_id") private CustomerNotes customerNotes;
	 */

	@Column(name = "customer_notes")
	private String customerNotes;

	@Column(name = "total")
	private double total;

	/*
	 * @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	 * 
	 * @JoinColumn(name = "terms_and_conditions_id") private TermsAndConditions
	 * termsAndConditions;
	 */

	@Column(name = "terms_and_conditions")
	private String termsAndConditions;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "b_sales_order_join_files", joinColumns = {
			@JoinColumn(name = "sales_order_id", referencedColumnName = "sales_order_id") }, inverseJoinColumns = {
					@JoinColumn(name = "files_id", referencedColumnName = "files_id") })
	private List<Files> files;

	@Column(name = "sub_total")
	private double subTotal;

	@Column(name = "round_off")
	private double roundOff;

	@Column(name = "sales_order_status")
	private String salesOrderStatus;

	@Column(name = "is_active")
	private boolean isActive;

	public String getSalesOrderUuid() {
		return salesOrderUuid;
	}

	public void setSalesOrderUuid(String salesOrderUuid) {
		this.salesOrderUuid = salesOrderUuid;
	}

	public CustomerMaster getCustomerMaster() {
		return customerMaster;
	}

	public void setCustomerMaster(CustomerMaster customerMaster) {
		this.customerMaster = customerMaster;
	}

	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}

	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public Date getSalesOrderDate() {
		return salesOrderDate;
	}

	public void setSalesOrderDate(Date salesOrderDate) {
		this.salesOrderDate = salesOrderDate;
	}

	public PaymentTerms getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(PaymentTerms paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public SalesPerson getSalesPerson() {
		return salesPerson;
	}

	public void setSalesPerson(SalesPerson salesPerson) {
		this.salesPerson = salesPerson;
	}

	/*
	 * public CustomerNotes getCustomerNotes() { return customerNotes; }
	 * 
	 * public void setCustomerNotes(CustomerNotes customerNotes) {
	 * this.customerNotes = customerNotes; }
	 */

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	/*
	 * public TermsAndConditions getTermsAndConditions() { return
	 * termsAndConditions; }
	 * 
	 * public void setTermsAndConditions(TermsAndConditions termsAndConditions) {
	 * this.termsAndConditions = termsAndConditions; }
	 */

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getRoundOff() {
		return roundOff;
	}

	public void setRoundOff(double roundOff) {
		this.roundOff = roundOff;
	}

	public String getSalesOrderStatus() {
		return salesOrderStatus;
	}

	public void setSalesOrderStatus(String salesOrderStatus) {
		this.salesOrderStatus = salesOrderStatus;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	

	

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	public List<Files> getFiles() {
		return files;
	}

	public void setFiles(List<Files> files) {
		this.files = files;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	public Date getExpectedShipmentDate() {
		return expectedShipmentDate;
	}

	public void setExpectedShipmentDate(Date expectedShipmentDate) {
		this.expectedShipmentDate = expectedShipmentDate;
	}

	public String getCustomerNotes() {
		return customerNotes;
	}

	public void setCustomerNotes(String customerNotes) {
		this.customerNotes = customerNotes;
	}

	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public BusinessUnit getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(BusinessUnit businessUnit) {
		this.businessUnit = businessUnit;
	}

	public ContactPerson getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(ContactPerson contactPerson) {
		this.contactPerson = contactPerson;
	}

	public ConsigneePerson getConsigneePerson() {
		return consigneePerson;
	}

	public void setConsigneePerson(ConsigneePerson consigneePerson) {
		this.consigneePerson = consigneePerson;
	}

}
