
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.lucene.analysis.core.LowerCaseFilterFactory;
import org.apache.lucene.analysis.ngram.EdgeNGramFilterFactory;
import org.apache.lucene.analysis.snowball.SnowballPorterFilterFactory;
import org.apache.lucene.analysis.standard.StandardTokenizerFactory;
import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Analyzer;
import org.hibernate.search.annotations.AnalyzerDef;
import org.hibernate.search.annotations.DocumentId;
import org.hibernate.search.annotations.Facet;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.Parameter;
import org.hibernate.search.annotations.TokenFilterDef;
import org.hibernate.search.annotations.TokenizerDef;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gloqr.books.constants.ItemType;
import com.gloqr.books.constants.TaxPreference;

@Entity
@Table(name = "b_item_master")
@Indexed
@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English"), }), })
@AnalyzerDef(name = "nGramAnalyzer", tokenizer = @TokenizerDef(factory = StandardTokenizerFactory.class), filters = {
		@TokenFilterDef(factory = LowerCaseFilterFactory.class),
		@TokenFilterDef(factory = SnowballPorterFilterFactory.class, params = {
				@Parameter(name = "language", value = "English"), }),
		@TokenFilterDef(factory = EdgeNGramFilterFactory.class, params = {
				@Parameter(name = "maxGramSize", value = "25"), @Parameter(name = "minGramSize", value = "2") }) })
public class ItemMaster extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_master_id")
	@DocumentId
	private Long itemMasterId;

	@Column(name = "book_uuid")
	@Field
	private String bookUuid;

	@Column(name = "item_master_uuid", nullable = false, updatable = false)
	private String itemMasterUuid;

	@Column(name = "type")
	private ItemType type;

//	@Field(analyze = Analyze.NO)
//	@Facet(encoding = FacetEncodingType.STRING)

//	@Field(index = Index.YES, store = Store.YES, analyze = Analyze.YES)
//	@Analyzer(definition = "edgecustomanalyzer1")

	@Column(name = "name")
	@Field
	@Analyzer(definition = "nGramAnalyzer")
	private String name;

	/*
	 * @Column(name = "hsn_code") private String hsnCode;
	 */

	@Column(name = "hsn_sac_code")
	private String hsnSacCode;

	@Column(name = "cgst_tax")
	private double cgstTax;

	@Column(name = "sgst_tax")
	private double sgstTax;

	@Column(name = "igst_tax")
	private double igstTax;

	@Column(name = "selling_price")
	private double sellingPrice;

	@Column(name = "cost_price")
	private double costPrice;

	@Column(name = "selling_description")
	private String sellingDescription;

	@Column(name = "purchase_description")
	private String purchaseDescription;

	@Column(name = "min_stock")
	private int minStock;

	@Column(name = "max_stock")
	private int maxStock;

	@Column(name = "tax_reference_type")
	@Enumerated(EnumType.STRING)
	private TaxPreference taxPreferance;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "sales_account_id", referencedColumnName = "account_master_id")
	private AccountMaster salesAccount;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "purchase_account_id", referencedColumnName = "account_master_id")
	private AccountMaster purchaseAccount;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "uom_id")
	private UOM uom;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "tax_master_id")
	private TaxMaster taxMaster;

	public Long getItemMasterId() {
		return itemMasterId;
	}

	public void setItemMasterId(Long itemMasterId) {
		this.itemMasterId = itemMasterId;
	}

	public String getItemMasterUuid() {
		return itemMasterUuid;
	}

	public void setItemMasterUuid(String itemMasterUuid) {
		this.itemMasterUuid = itemMasterUuid;
	}



	public ItemType getType() {
		return type;
	}

	public void setType(ItemType type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getHsnSacCode() {
		return hsnSacCode;
	}

	public void setHsnSacCode(String hsnSacCode) {
		this.hsnSacCode = hsnSacCode;
	}

	public double getCgstTax() {
		return cgstTax;
	}

	public void setCgstTax(double cgstTax) {
		this.cgstTax = cgstTax;
	}

	public double getSgstTax() {
		return sgstTax;
	}

	public void setSgstTax(double sgstTax) {
		this.sgstTax = sgstTax;
	}

	public double getIgstTax() {
		return igstTax;
	}

	public void setIgstTax(double igstTax) {
		this.igstTax = igstTax;
	}

	public double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public double getCostPrice() {
		return costPrice;
	}

	public void setCostPrice(double costPrice) {
		this.costPrice = costPrice;
	}

	public String getSellingDescription() {
		return sellingDescription;
	}

	public void setSellingDescription(String sellingDescription) {
		this.sellingDescription = sellingDescription;
	}

	public String getPurchaseDescription() {
		return purchaseDescription;
	}

	public void setPurchaseDescription(String purchaseDescription) {
		this.purchaseDescription = purchaseDescription;
	}

	public int getMinStock() {
		return minStock;
	}

	public void setMinStock(int minStock) {
		this.minStock = minStock;
	}

	public int getMaxStock() {
		return maxStock;
	}

	public void setMaxStock(int maxStock) {
		this.maxStock = maxStock;
	}

	public TaxPreference getTaxPreferance() {
		return taxPreferance;
	}

	public void setTaxPreferance(TaxPreference taxPreferance) {
		this.taxPreferance = taxPreferance;
	}

	public AccountMaster getSalesAccount() {
		return salesAccount;
	}

	public void setSalesAccount(AccountMaster salesAccount) {
		this.salesAccount = salesAccount;
	}

	public AccountMaster getPurchaseAccount() {
		return purchaseAccount;
	}

	public void setPurchaseAccount(AccountMaster purchaseAccount) {
		this.purchaseAccount = purchaseAccount;
	}

	public UOM getUom() {
		return uom;
	}

	public void setUom(UOM uom) {
		this.uom = uom;
	}

	public TaxMaster getTaxMaster() {
		return taxMaster;
	}

	public void setTaxMaster(TaxMaster taxMaster) {
		this.taxMaster = taxMaster;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

}
