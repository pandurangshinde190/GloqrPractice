package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.SalesPerson;

public interface SalesPersonRepo extends JpaRepository<SalesPerson, Long>{

	SalesPerson findBysalesPersonUuid(String salesPersonUuid);
	
	List<SalesPerson> findByBookUuid(String bookUuid);
}
