package com.gloqr.books.constants;

public enum CustomerType {

	BUSINESS,INDIVIDUAL
}
