package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "b_sales_person")
public class SalesPerson extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="sales_person_id")
	private Long salesPersonId;

	@Column(name = "sales_person_uuid", nullable = false, updatable = false)
	private String salesPersonUuid;
	
	@Column(name = "sales_person_name")
	private String salesPersonName;
	
	@Column(name = "sales_person_email")
	private String salesPersonEmail;
	
	@Column(name = "book_uuid")
	private String bookUuid;

	public Long getSalesPersonId() {
		return salesPersonId;
	}

	public void setSalesPersonId(Long salesPersonId) {
		this.salesPersonId = salesPersonId;
	}

	public String getSalesPersonUuid() {
		return salesPersonUuid;
	}

	public void setSalesPersonUuid(String salesPersonUuid) {
		this.salesPersonUuid = salesPersonUuid;
	}

	public String getSalesPersonName() {
		return salesPersonName;
	}

	public void setSalesPersonName(String salesPersonName) {
		this.salesPersonName = salesPersonName;
	}

	public String getSalesPersonEmail() {
		return salesPersonEmail;
	}

	public void setSalesPersonEmail(String salesPersonEmail) {
		this.salesPersonEmail = salesPersonEmail;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}
	
	
}
