package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.CustomerMaster;

public interface CustomerMasterRepo extends JpaRepository<CustomerMaster, Long>{
	
	CustomerMaster findByCustomerMUuid(String customerMUuid);
	
	List<CustomerMaster> findByBookUuid(String bookUuid,Pageable pageable);
	
	List<CustomerMaster> findByBookUuid(String bookUuid);

}
