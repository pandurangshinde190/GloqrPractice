package com.gloqr.books.constants;

public enum DiscountType {

	PERCENTAGE,RUPEES
}
