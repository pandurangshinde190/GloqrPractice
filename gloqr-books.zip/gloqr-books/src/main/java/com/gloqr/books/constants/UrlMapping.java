package com.gloqr.books.constants;

public final class UrlMapping {
	public static final String ROOT_API = "/api/books";
	public static final String GLOQR_ADMIN_API = ROOT_API + "/gloqr-admin";

	private UrlMapping() {
		throw new IllegalStateException("UrlMapping class.can't initiate");
	}

	public class FileDirectory {
		public static final String FILE_DIR = "sme/{smeId}/bookFiles";
	}
	/* BookMasterControllerUrls */

	public static final String SELF_MASTER = "/self/master";
	public static final String BOOK_STATUS = "/status";
	public static final String GST_TREATMENT = "/gst-treatment";
	public static final String PAYMENT_TERMS = "/payment-terms";
	public static final String GET_GST_TREATMENT = "/view/gst-treatment";
	public static final String SALES_PERSON = "/sales-person";
	public static final String CUSTOMER_NOTES = "/customer-notes";
	public static final String TERMS_AND_CONDITIONS = "/terms-and-conditions";
	public static final String GET_BOOK_UUID = "/book-id";
	
	//Item Master Controller Url's
	public static final String ITEM = "/items";
	public static final String TAX_MASTER="/tax";
	public static final String UOM_MASTER="/uom";
	public static final String ACCOUNT_MASTER="/account";
	public static final String LEDGER="/ledger";	
	public static final String GET_ITEM = "/item";
	
	
	/* SalesOrderControllerUrls */
	
	public static final String SALES_ORDER="/sales-order";
	public static final String GET_SALES_ORDER = "/get-sales-order";
	public static final String GET_BUSINESS_UNIT_FOR_CUSTOMER="/get-business-units";
	public static final String GET_CONTACT_PERSON_FOR_CUSTOMER="/get-contact-persons";
	public static final String GET_CONSIGNEE_PERSON_FOR_CUSTOMER = "/get-consignee-persons";
	public static final String GET_SELF_MASTER_STATE = "/get-self-state";
	
	/* FileController Urls */
	public static final String UPLOAD_FILES="/upload-files";
	
	
	/* CustomerMasterController URLs */
	public static final String CUSTOMER = "/customer";
	public static final String BUSINESS_UNIT = "/business-unit";
	public static final String CUSTOMER_LIST = "/customer-list";
	public static final String GET_CUSTOMER = "/get-customer";
	
	public static final String ITEM_SEARCH_SUGGEST = "/item-search-suggest";
	
}
