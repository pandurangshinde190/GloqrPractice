package com.gloqr.books.constants;

public enum AddressType {
	BILLING_ADDRESS,SHIPPING_ADDRESS,SELF_ADDRESS,BUSINESS_UNIT
}
