package com.gloqr.books.dto;

import java.util.Date;
import java.util.Set;

public class SalesOrderVO {

	private String salesOrderUuid;

	private CustomerMasterVO customerMaster;

	private String salesOrderNumber;

	private String referenceNumber;

	private Date salesOrderDate;

	private PaymentTermsDto paymentTerms;

	private String deliveryMethod;

	private SalesPersonDto salesPerson;

	private String customerNotes;

	private double total;

	private String termsAndConditions;

	private double subTotal;

	private double roundOff;

	private String salesOrderStatus;

	private boolean isActive;
    
	private String bookUuid;

	private Date expectedShipmentDate;
	
	private Set<OrderItemDto> orderItems;
		
    private Set<FilesDto> files;
    
    private ContactPersonDto contactPerson;
    
    private ConsigneePersonDto consigneePerson;
    
    private BusinessUnitDto businessUnit;

	public String getSalesOrderUuid() {
		return salesOrderUuid;
	}

	public void setSalesOrderUuid(String salesOrderUuid) {
		this.salesOrderUuid = salesOrderUuid;
	}
	
	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}

	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public Date getSalesOrderDate() {
		return salesOrderDate;
	}

	public void setSalesOrderDate(Date salesOrderDate) {
		this.salesOrderDate = salesOrderDate;
	}

	

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	

	public String getCustomerNotes() {
		return customerNotes;
	}

	public void setCustomerNotes(String customerNotes) {
		this.customerNotes = customerNotes;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getRoundOff() {
		return roundOff;
	}

	public void setRoundOff(double roundOff) {
		this.roundOff = roundOff;
	}

	public String getSalesOrderStatus() {
		return salesOrderStatus;
	}

	public void setSalesOrderStatus(String salesOrderStatus) {
		this.salesOrderStatus = salesOrderStatus;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	public Date getExpectedShipmentDate() {
		return expectedShipmentDate;
	}

	public void setExpectedShipmentDate(Date expectedShipmentDate) {
		this.expectedShipmentDate = expectedShipmentDate;
	}

	public CustomerMasterVO getCustomerMaster() {
		return customerMaster;
	}

	public void setCustomerMaster(CustomerMasterVO customerMaster) {
		this.customerMaster = customerMaster;
	}

	public PaymentTermsDto getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(PaymentTermsDto paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public SalesPersonDto getSalesPerson() {
		return salesPerson;
	}

	public void setSalesPerson(SalesPersonDto salesPerson) {
		this.salesPerson = salesPerson;
	}

	public Set<OrderItemDto> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(Set<OrderItemDto> orderItems) {
		this.orderItems = orderItems;
	}

	public Set<FilesDto> getFiles() {
		return files;
	}

	public void setFiles(Set<FilesDto> files) {
		this.files = files;
	}

	public ContactPersonDto getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(ContactPersonDto contactPerson) {
		this.contactPerson = contactPerson;
	}

	public ConsigneePersonDto getConsigneePerson() {
		return consigneePerson;
	}

	public void setConsigneePerson(ConsigneePersonDto consigneePerson) {
		this.consigneePerson = consigneePerson;
	}

	public BusinessUnitDto getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(BusinessUnitDto businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	

}
