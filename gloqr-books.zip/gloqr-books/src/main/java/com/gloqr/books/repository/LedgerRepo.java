package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.Ledger;

public interface LedgerRepo extends JpaRepository<Ledger,Long>{

}
