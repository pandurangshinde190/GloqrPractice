package com.gloqr.books.dto;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.gloqr.books.entities.CustomerMaster;
import com.gloqr.books.entities.CustomerNotes;
import com.gloqr.books.entities.Files;
import com.gloqr.books.entities.OrderItem;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SalesPerson;
import com.gloqr.books.entities.TermsAndConditions;

public class SalesOrderDto {

	private String salesOrderUuid;

	private CustomerMasterDto customerMasterDto;
	
	private BusinessUnitListDto businessUnitListDto;
	
	private ContactPersonListDto contactPersonListDto;
	
	private ConsigneePersonListDto consigneePersonListDto;

	private String salesOrderNumber;

	private String referenceNumber;

	private Date salesOrderDate;

	private PaymentTermsDto paymentTermsDto;

	private String deliveryMethod;

	private SalesPersonDto salesPersonDto;

	private String customerNotes;

	private double total;

	private String termsAndConditions;

	private double subTotal;

	private double roundOff;

	private String salesOrderStatus;

	private boolean isActive;
	
    private List<OrderItemDto> orderItems;
	
    private List<FilesDto> files;
    
    private String customerMUuid;
    
    private String paymentTermsUuid;

    private String salesPersonUuid;
    
	private String bookUuid;
	
	private String businessUnitUuid;
	
	private String contactPersonUuid;
	
	private String consigneePersonUuid;
	
	

	private Date expectedShipmentDate;

	public String getSalesOrderUuid() {
		return salesOrderUuid;
	}

	public void setSalesOrderUuid(String salesOrderUuid) {
		this.salesOrderUuid = salesOrderUuid;
	}

	

	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}

	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	
	public Date getSalesOrderDate() {
		return salesOrderDate;
	}

	public void setSalesOrderDate(Date salesOrderDate) {
		this.salesOrderDate = salesOrderDate;
	}

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	
	

	

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	

	

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getRoundOff() {
		return roundOff;
	}

	public void setRoundOff(double roundOff) {
		this.roundOff = roundOff;
	}

	public String getSalesOrderStatus() {
		return salesOrderStatus;
	}

	public void setSalesOrderStatus(String salesOrderStatus) {
		this.salesOrderStatus = salesOrderStatus;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	

	public String getCustomerMUuid() {
		return customerMUuid;
	}

	public void setCustomerMUuid(String customerMUuid) {
		this.customerMUuid = customerMUuid;
	}

	public String getPaymentTermsUuid() {
		return paymentTermsUuid;
	}

	public void setPaymentTermsUuid(String paymentTermsUuid) {
		this.paymentTermsUuid = paymentTermsUuid;
	}

	public String getSalesPersonUuid() {
		return salesPersonUuid;
	}

	public void setSalesPersonUuid(String salesPersonUuid) {
		this.salesPersonUuid = salesPersonUuid;
	}

	

	public CustomerMasterDto getCustomerMasterDto() {
		return customerMasterDto;
	}

	public void setCustomerMasterDto(CustomerMasterDto customerMasterDto) {
		this.customerMasterDto = customerMasterDto;
	}

	public BusinessUnitListDto getBusinessUnitListDto() {
		return businessUnitListDto;
	}

	public void setBusinessUnitListDto(BusinessUnitListDto businessUnitListDto) {
		this.businessUnitListDto = businessUnitListDto;
	}

	public ContactPersonListDto getContactPersonListDto() {
		return contactPersonListDto;
	}

	public void setContactPersonListDto(ContactPersonListDto contactPersonListDto) {
		this.contactPersonListDto = contactPersonListDto;
	}

	public ConsigneePersonListDto getConsigneePersonListDto() {
		return consigneePersonListDto;
	}

	public void setConsigneePersonListDto(ConsigneePersonListDto consigneePersonListDto) {
		this.consigneePersonListDto = consigneePersonListDto;
	}

	public PaymentTermsDto getPaymentTermsDto() {
		return paymentTermsDto;
	}

	public void setPaymentTermsDto(PaymentTermsDto paymentTermsDto) {
		this.paymentTermsDto = paymentTermsDto;
	}

	public SalesPersonDto getSalesPersonDto() {
		return salesPersonDto;
	}

	public void setSalesPersonDto(SalesPersonDto salesPersonDto) {
		this.salesPersonDto = salesPersonDto;
	}


	public List<OrderItemDto> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItemDto> orderItems) {
		this.orderItems = orderItems;
	}

	public List<FilesDto> getFiles() {
		return files;
	}

	public void setFiles(List<FilesDto> files) {
		this.files = files;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	public Date getExpectedShipmentDate() {
		return expectedShipmentDate;
	}

	public void setExpectedShipmentDate(Date expectedShipmentDate) {
		this.expectedShipmentDate = expectedShipmentDate;
	}

	public String getCustomerNotes() {
		return customerNotes;
	}

	public void setCustomerNotes(String customerNotes) {
		this.customerNotes = customerNotes;
	}

	public String getTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(String termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public String getBusinessUnitUuid() {
		return businessUnitUuid;
	}

	public void setBusinessUnitUuid(String businessUnitUuid) {
		this.businessUnitUuid = businessUnitUuid;
	}

	public String getContactPersonUuid() {
		return contactPersonUuid;
	}

	public void setContactPersonUuid(String contactPersonUuid) {
		this.contactPersonUuid = contactPersonUuid;
	}

	public String getConsigneePersonUuid() {
		return consigneePersonUuid;
	}

	public void setConsigneePersonUuid(String consigneePersonUuid) {
		this.consigneePersonUuid = consigneePersonUuid;
	}
	
}
