package com.gloqr.books.dto;


public class CustomerNotesDto {

	private String customerNotesUuid;

	private String type;

	private String description;
	
	private String bookUuid;

	public String getCustomerNotesUuid() {
		return customerNotesUuid;
	}

	public void setCustomerNotesUuid(String customerNotesUuid) {
		this.customerNotesUuid = customerNotesUuid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	
}
