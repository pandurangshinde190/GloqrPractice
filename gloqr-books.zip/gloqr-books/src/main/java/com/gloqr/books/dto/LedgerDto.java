package com.gloqr.books.dto;

import com.gloqr.books.entities.AccountMaster;

public class LedgerDto {
	
	private String ledgerUuid;

	private String ledgerName;

	private AccountMasterDto accountMaster;
	
	private String accountMasterUuid;

	public String getLedgerUuid() {
		return ledgerUuid;
	}

	public void setLedgerUuid(String ledgerUuid) {
		this.ledgerUuid = ledgerUuid;
	}

	public String getLedgerName() {
		return ledgerName;
	}

	public void setLedgerName(String ledgerName) {
		this.ledgerName = ledgerName;
	}

	



	public AccountMasterDto getAccountMaster() {
		return accountMaster;
	}

	public void setAccountMaster(AccountMasterDto accountMaster) {
		this.accountMaster = accountMaster;
	}

	public String getAccountMasterUuid() {
		return accountMasterUuid;
	}

	public void setAccountMasterUuid(String accountMasterUuid) {
		this.accountMasterUuid = accountMasterUuid;
	}
	
	


}
