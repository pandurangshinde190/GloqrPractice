package com.gloqr.books.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.gloqr.books.constants.CreditType;
import com.gloqr.books.dto.CustomErrorResponse;
import com.gloqr.books.dto.CustomHttpResponse;

@Component
public class ResponseMaker {

	private <T> CustomHttpResponse<T> getObj(HttpStatus status) {
		return new CustomHttpResponse<>(status.value(), status);
	}

	public <T> ResponseEntity<CustomHttpResponse<T>> successResponse(T data, HttpStatus status) {
		CustomHttpResponse<T> response = getObj(status);
		response.setData(data);

		return new ResponseEntity<>(response, status);
	}

	public <T> ResponseEntity<CustomHttpResponse<T>> errorResponse(String message, HttpStatus status) {
		CustomHttpResponse<T> response = getObj(status);
		response.setMessage(message);
		response.setError(true);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	public <T> ResponseEntity<CustomHttpResponse<T>> noCreditsResponse(CreditType creditType) {
		CustomHttpResponse<T> response = getObj(HttpStatus.PAYMENT_REQUIRED);
		String msg = "No credits left for " + creditType.getValue();
		response.setError(true);
		response.setErrorResponse(new CustomErrorResponse(creditType.getCode(), msg,creditType.getValue()));

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	public <T> ResponseEntity<CustomHttpResponse<T>> successResponse(T data, String message, HttpStatus status) {
		CustomHttpResponse<T> response = getObj(status, message);
		response.setData(data);

		return ResponseEntity.ok(response);
	}
	
	private <T> CustomHttpResponse<T> getObj(HttpStatus status, String message) {
		return new CustomHttpResponse<>(status.value(), status, message);
	}

}
