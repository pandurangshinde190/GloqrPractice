package com.gloqr.books.constants;

public enum ItemType {
	GOODS,SERVICE
}
