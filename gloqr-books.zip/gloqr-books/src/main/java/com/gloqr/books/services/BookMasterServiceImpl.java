package com.gloqr.books.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.gloqr.books.constants.AddressType;
import com.gloqr.books.dao.BookMasterDao;
import com.gloqr.books.dto.CustomerNotesDto;
import com.gloqr.books.dto.GstTreatmentDto;
import com.gloqr.books.dto.PaymentTermsDto;
import com.gloqr.books.dto.SMEInfoDto;
import com.gloqr.books.dto.SalesPersonDto;
import com.gloqr.books.dto.TermsAndConditionsDto;
import com.gloqr.books.endpoints.SmeEndpoint;
import com.gloqr.books.entities.Address;
import com.gloqr.books.entities.CustomerNotes;
import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.PaymentTerms;
import com.gloqr.books.entities.SalesPerson;
//import com.gloqr.books.entities.GstTreatment;
import com.gloqr.books.entities.SelfMaster;
import com.gloqr.books.entities.TermsAndConditions;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.CustomerNotesRepo;
import com.gloqr.books.repository.PaymentTermsRepo;
import com.gloqr.books.repository.SalesPersonRepo;
import com.gloqr.books.repository.SelfMasterRepo;
import com.gloqr.books.repository.TermsAndConditionsRepo;
import com.gloqr.books.util.UuidUtil;

@Service
public class BookMasterServiceImpl implements BookMasterService {

	@Autowired
	SmeEndpoint smeEndpoint;

	@Autowired
	BookMasterDao bookMasterDao;

	@Autowired
	Mapper mapper;
	
	@Autowired
	SelfMasterRepo selfMasterRepo;
	
	@Autowired
	PaymentTermsRepo paymentTermsRepo;

	@Autowired
	SalesPersonRepo salesPersonRepo;
	
	@Autowired
	CustomerNotesRepo customerNotesRepo;
	
	@Autowired
	TermsAndConditionsRepo termsAndConditionsRepo;
	
	@Override
	public String saveSelfMasterDetails(String userUuid) {
		SMEInfoDto smeInfoDto = smeEndpoint.getSmeInformation(userUuid);
		SelfMaster selfMaster = new SelfMaster();
		if (smeInfoDto != null) {
			selfMaster.setSuuid(smeInfoDto.getsUuid());
			selfMaster.setUuid(smeInfoDto.getUuid());
			selfMaster.setSmeName(smeInfoDto.getSmeName());
			selfMaster.setContactEmail(smeInfoDto.getContactEmail());
			selfMaster.setAddress(mapper.convertToEntity(smeInfoDto.getSmeAddress(),Address.class));
			selfMaster.getAddress().setAddressType(AddressType.SELF_ADDRESS);
			selfMaster.setContactPhone(smeInfoDto.getContactPhone());
			selfMaster.setGstin(smeInfoDto.getGstin());
			selfMaster.setLogoImage(smeInfoDto.getLogoImage());
			selfMaster.setBookUuid(UuidUtil.getUuid("b_" + smeInfoDto.getSmeName()));
			selfMaster.setSelfMasterUuid(UuidUtil.getUuid("b_s_" + smeInfoDto.getSmeName()));
			selfMaster.setSmeState(smeInfoDto.getSmeState());
			bookMasterDao.saveSelfMasterDetails(selfMaster);
		} else {
			throw new CustomException("sme not found with userId :: " + userUuid, HttpStatus.NOT_FOUND);
		}
		return "Self Master Details saved successfully.";
	}

	@Override
	public Map<String, Boolean> bookStatus(String userUuid) {

		return bookMasterDao.getBookStatus(userUuid);
	}

	@Override
	public String postGstTreatment(GstTreatmentDto gstTreatmentDto) {
		gstTreatmentDto.setGstTreatmentUuid(UuidUtil.getUuid(gstTreatmentDto.getTitle()));
		GstTreatment gstTreatment = mapper.convertToEntity(gstTreatmentDto, GstTreatment.class);
		return bookMasterDao.saveGstTreatment(gstTreatment);
	}

	@Override
	public List<GstTreatmentDto> getGstTreatment() {
		return bookMasterDao.getGstTreatment();
	}

	@Override
	public String savePaymentTerms(PaymentTermsDto paymentTermsDto,String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		paymentTermsDto.setBookUuid(selfMaster.getBookUuid());
		paymentTermsDto.setPaymentTermsUuid(UuidUtil.getUuid(paymentTermsDto.getTermName()));
		PaymentTerms paymentTerms = mapper.convertToEntity(paymentTermsDto, PaymentTerms.class);
		bookMasterDao.savePaymentTermsDetails(paymentTerms);
		return "Payment terms details saved successfully";
	}

	@Override
	public String saveSalesPerson(SalesPersonDto salesPersonDto,String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		salesPersonDto.setBookUuid(selfMaster.getBookUuid());
		salesPersonDto.setSalesPersonUuid(UuidUtil.getUuid(salesPersonDto.getSalesPersonName()));
		SalesPerson salesPerson = mapper.convertToEntity(salesPersonDto, SalesPerson.class);
		bookMasterDao.saveSalesPersonDetails(salesPerson);
		return "Sales person details are saved successfully.";
	}

	@Override
	public String saveCustomerNotes(CustomerNotesDto customerNotesDto,String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		customerNotesDto.setBookUuid(selfMaster.getBookUuid());
		customerNotesDto.setCustomerNotesUuid(UuidUtil.getUuid());
		CustomerNotes customerNotes = mapper.convertToEntity(customerNotesDto, CustomerNotes.class);
		bookMasterDao.saveCustomerNotes(customerNotes);
		return "Customer Notes saved successfully.";
	}

	@Override
	public String saveTermsAndConditions(TermsAndConditionsDto termsAndConditionsDto,String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		termsAndConditionsDto.setBookUuid(selfMaster.getBookUuid());
		termsAndConditionsDto.setTermsUuid(UuidUtil.getUuid());
		TermsAndConditions termsAndConditions = mapper.convertToEntity(termsAndConditionsDto, TermsAndConditions.class);
		bookMasterDao.saveTermsAndConditions(termsAndConditions);
		return "Terms and conditions saved successfully.";
	}

	@Override
	public Map<String, String> getBookUuid(String userUuid) {
		return bookMasterDao.getBookUuid(userUuid);
	}

	@Override
	public List<PaymentTermsDto> getPaymentTerms(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		List<PaymentTerms> paymentTermsList = paymentTermsRepo.findByBookUuid(selfMaster.getBookUuid());
		List<PaymentTermsDto> paymentTermsDtos=new ArrayList<PaymentTermsDto>();
		for(PaymentTerms paymentTerms:paymentTermsList) {
			PaymentTermsDto paymentTermsDto = mapper.convertToDto(paymentTerms, PaymentTermsDto.class);
			paymentTermsDtos.add(paymentTermsDto);
		}
		return paymentTermsDtos;
	}

	@Override
	public List<SalesPersonDto> getSalesPersonDetials(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		List<SalesPerson> salesPersonList = salesPersonRepo.findByBookUuid(selfMaster.getBookUuid());
		List<SalesPersonDto> salesPersonDtos = new ArrayList<SalesPersonDto>();
		for(SalesPerson salesPerson:salesPersonList) {
			SalesPersonDto salesPersonDto = mapper.convertToDto(salesPerson, SalesPersonDto.class);
			salesPersonDtos.add(salesPersonDto);
		}
		return salesPersonDtos;
	}

	@Override
	public List<CustomerNotesDto> getCustomerNotes(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		List<CustomerNotes> customerNotesList = customerNotesRepo.findByBookUuid(selfMaster.getBookUuid());
		List<CustomerNotesDto> customerNotesDtos = new ArrayList<CustomerNotesDto>();
		for(CustomerNotes customerNotes:customerNotesList) {
			CustomerNotesDto customerNotesDto = mapper.convertToDto(customerNotes, CustomerNotesDto.class);
			customerNotesDtos.add(customerNotesDto);
		}
		return customerNotesDtos;
	}

	@Override
	public List<TermsAndConditionsDto> getTermsAndConditions(String userUuid) {
		SelfMaster selfMaster = selfMasterRepo.findByUuid(userUuid);
		List<TermsAndConditions> termsAndConditions = termsAndConditionsRepo.findByBookUuid(selfMaster.getBookUuid());
		List<TermsAndConditionsDto> termsAndConditionsDtos = new ArrayList<TermsAndConditionsDto>();
		for(TermsAndConditions tc:termsAndConditions) {
			TermsAndConditionsDto termsAndConditionsDto = mapper.convertToDto(tc, TermsAndConditionsDto.class);
			termsAndConditionsDtos.add(termsAndConditionsDto);
		}		
		return termsAndConditionsDtos;
	}


}
