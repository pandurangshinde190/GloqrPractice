package com.gloqr.books.dto;

public class FilesDto {

	private String filesUuid;
	
	private String name;

	private String type;

	private String location;

	private String referenceId;

	private long size;
	
	private boolean isActive;

	private String salesOrderUuid;


	public String getFilesUuid() {
		return filesUuid;
	}

	public void setFilesUuid(String filesUuid) {
		this.filesUuid = filesUuid;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

}
