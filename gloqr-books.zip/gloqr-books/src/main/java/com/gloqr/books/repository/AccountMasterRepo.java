package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.AccountMaster;

public interface AccountMasterRepo extends JpaRepository<AccountMaster,Long>{

	AccountMaster findByAccountMasterUuid(String accountMasterUuid);
}
