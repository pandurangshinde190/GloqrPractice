package com.gloqr.books.dao;

import java.util.List;

import com.gloqr.books.dto.CustomerListDto;
import com.gloqr.books.dto.CustomerMasterVO;
import com.gloqr.books.entities.BusinessUnit;
import com.gloqr.books.entities.CustomerMaster;

public interface CustomerMasterDao {

	String saveCustomerMasterDetails(CustomerMaster customerMaster);
	
	String saveBusinessUnitDetails(BusinessUnit businessUnit);
	
	List<CustomerMasterVO> getCustomerMasterDetails(String bookUuid,int page);
	
	List<CustomerListDto> getCustomerList(String bookUuid);
	
	CustomerMasterVO getCustomer(String customerMUuid);
	
	void updateCustomerMaster(CustomerMaster customerMaster);
}
