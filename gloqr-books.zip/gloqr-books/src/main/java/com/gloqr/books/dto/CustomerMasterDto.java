package com.gloqr.books.dto;

import java.util.List;
import java.util.Set;


import com.gloqr.books.constants.CustomerType;


public class CustomerMasterDto {

	private String customerMUuid;
	
	private Boolean isDefault;


	
	private String contactPhone;

	private String contactMobile;

	private String contactEmail;

	private String website;
	
	private String vendorCode;

	private double openingBalance;

	private int creditDays;

	private CustomerType customerType;

	/*
	 * private AddressDto billingAddress;
	 * 
	 * private AddressDto shippingAddress;
	 */
	
	private List<ContactPersonDto> contactPersons;
	
	private List<ConsigneePersonDto> consigneePersons;
	
	private List<BusinessUnitDto> businessUnits;
	
	private String gstTreatmentUuid;
	
	private String paymentTermsUuid;

	
	private String bookUuid;
	
	private String customerName;

	public String getCustomerMUuid() {
		return customerMUuid;
	}


	public void setCustomerMUuid(String customerMUuid) {
		this.customerMUuid = customerMUuid;
	}


	public String getContactPhone() {
		return contactPhone;
	}


	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}


	public String getContactEmail() {
		return contactEmail;
	}


	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}


	public String getWebsite() {
		return website;
	}


	public void setWebsite(String website) {
		this.website = website;
	}


	public String getVendorCode() {
		return vendorCode;
	}


	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}


	


	public double getOpeningBalance() {
		return openingBalance;
	}


	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}


	

	public int getCreditDays() {
		return creditDays;
	}


	public void setCreditDays(int creditDays) {
		this.creditDays = creditDays;
	}


	public CustomerType getCustomerType() {
		return customerType;
	}


	public void setCustomerType(CustomerType customerType) {
		this.customerType = customerType;
	}


	public String getContactMobile() {
		return contactMobile;
	}


	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}


	public String getGstTreatmentUuid() {
		return gstTreatmentUuid;
	}


	public void setGstTreatmentUuid(String gstTreatmentUuid) {
		this.gstTreatmentUuid = gstTreatmentUuid;
	}


	public String getPaymentTermsUuid() {
		return paymentTermsUuid;
	}


	public void setPaymentTermsUuid(String paymentTermsUuid) {
		this.paymentTermsUuid = paymentTermsUuid;
	}



	public String getBookUuid() {
		return bookUuid;
	}


	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}


	


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public List<ContactPersonDto> getContactPersons() {
		return contactPersons;
	}


	public void setContactPersons(List<ContactPersonDto> contactPersons) {
		this.contactPersons = contactPersons;
	}


	public List<ConsigneePersonDto> getConsigneePersons() {
		return consigneePersons;
	}


	public void setConsigneePersons(List<ConsigneePersonDto> consigneePersons) {
		this.consigneePersons = consigneePersons;
	}


	public List<BusinessUnitDto> getBusinessUnits() {
		return businessUnits;
	}


	public void setBusinessUnits(List<BusinessUnitDto> businessUnits) {
		this.businessUnits = businessUnits;
	}


	public Boolean getIsDefault() {
		return isDefault;
	}


	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}


	

}
