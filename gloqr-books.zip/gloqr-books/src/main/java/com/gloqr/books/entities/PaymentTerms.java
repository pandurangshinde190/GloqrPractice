
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "b_payment_terms")
public class PaymentTerms extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_terms_id")
	private Long paymentTermsId;

	@Column(name = "payment_terms_uuid", nullable = false, updatable = false)
	private String paymentTermsUuid;

	@Column(name = "term_name")
	private String termName;

	@Column(name = "number_of_days")
	private int numberOfDays;
	
	@Column(name = "book_uuid")
	private String bookUuid;

	public Long getPaymentTermsId() {
		return paymentTermsId;
	}

	public void setPaymentTermsId(Long paymentTermsId) {
		this.paymentTermsId = paymentTermsId;
	}

	public String getPaymentTermsUuid() {
		return paymentTermsUuid;
	}

	public void setPaymentTermsUuid(String paymentTermsUuid) {
		this.paymentTermsUuid = paymentTermsUuid;
	}

	public String getTermName() {
		return termName;
	}

	public void setTermName(String termName) {
		this.termName = termName;
	}

	public int getNumberOfDays() {
		return numberOfDays;
	}

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

}
