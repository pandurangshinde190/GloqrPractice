package com.gloqr.books.dto;

public class BusinessUnitListDto {
	
	private String businessUnitUuid;
	
	private String unitName;

	private Boolean isDefault;
	
	private String state;

	public String getBusinessUnitUuid() {
		return businessUnitUuid;
	}

	public void setBusinessUnitUuid(String businessUnitUuid) {
		this.businessUnitUuid = businessUnitUuid;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
