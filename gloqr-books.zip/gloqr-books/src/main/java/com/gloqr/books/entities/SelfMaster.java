package com.gloqr.books.entities;



import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;




@Entity
@Table(name = "b_self_master")
public class SelfMaster extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "self_master_id")
	private Long selfMasterId;

	@Column(name = "self_master_uuid", nullable = false, updatable = false)
	private String selfMasterUuid;

	@Column(name = "sme_name")
	private String smeName;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "address_id")
	private Address address;

	@Column(name = "logo_image")
	private String logoImage;

	@Column(name = "gstin")
	private String gstin;

	@Column(name = "phone")
	private String contactPhone;

	@Column(name = "email")
	private String contactEmail;

	@Column(name = "mobile")
	private String mobile;

	@Column(name = "website")
	private String website;

	@Column(name = "state")
	private String smeState;

	@Column(name = "sme_uuid")
	private String suuid;

	@Column(name = "user_uuid")
	private String uuid;

	@Column(name = "book_uuid")
	private String bookUuid;

	public SelfMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getSelfMasterId() {
		return selfMasterId;
	}

	public void setSelfMasterId(Long selfMasterId) {
		this.selfMasterId = selfMasterId;
	}

	public String getSelfMasterUuid() {
		return selfMasterUuid;
	}

	public void setSelfMasterUuid(String selfMasterUuid) {
		this.selfMasterUuid = selfMasterUuid;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}


	
	

	public String getSuuid() {
		return suuid;
	}

	public void setSuuid(String suuid) {
		this.suuid = suuid;
	}


	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getBookUuid() {
		return bookUuid;
	}

	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getLogoImage() {
		return logoImage;
	}

	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getSmeState() {
		return smeState;
	}

	public void setSmeState(String smeState) {
		this.smeState = smeState;
	}

}
