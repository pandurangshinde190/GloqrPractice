package com.gloqr.books.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.books.entities.Files;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.repository.FilesRepo;



@Repository
public class FilesDaoImpl implements FilesDao{

	@Autowired
	FilesRepo filesRepo;
	
	@Override
	public void saveFiles(List<Files> files) {
		try {
			filesRepo.saveAll(files);
		} catch (Exception e) {
			throw new CustomException("Exception in saveMultipleFiles( ) { }. message: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
