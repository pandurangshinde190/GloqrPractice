package com.gloqr.books.constants;

public enum CreditType {
	
	PRODUCT_SERVICE_LISTING(100, "Product/ Service Listing"),
	CIRCLE_CONNECTION(101, "Active Connections Allowed"),
	BUSINESS_INTEREST_VIEW(102, "Business Interest Read"),
	JOB_POSTING(103, "Job Postings"),
	/*BUSINESS_POST(104, "Business Update Postings"),*/
	IMAGE_STORAGE(105, "Image Storage");
	
	private final int code;
	private final String value;

	private CreditType(int code,String value) {
		this.code = code;
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}
	
	public int getCode() {
		return this.code;
	}
	
}
