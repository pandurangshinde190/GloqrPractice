package com.gloqr.books.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.SalesOrder;

public interface SalesOrderRepo extends JpaRepository<SalesOrder, Long>{

	List<SalesOrder> findByBookUuid(String bookUuid,Pageable pageable);
	
	SalesOrder findBySalesOrderUuid(String salesOrderUuid);
}
