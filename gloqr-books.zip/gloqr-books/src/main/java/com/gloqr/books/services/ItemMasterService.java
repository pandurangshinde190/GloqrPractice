package com.gloqr.books.services;

import java.util.List;

import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.LedgerDto;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.ItemMaster;

public interface ItemMasterService {

	String addItemMaster(ItemMasterDto itemMaster,String uuid);

	
	List<TaxMasterDto> getTaxMaster();
	
	List<UOMMasterDto> getUomMaster();
	
	List<AccountMasterDto> getAccountMaster();
	
	String saveTaxMasterDetails(TaxMasterDto taxMasterDto);
	
	String saveUomMasterDetails(UOMMasterDto uomMasterDto);
	
	String saveAccountMasterDetails(AccountMasterDto accountMasterDto);
	
	String saveLedger(LedgerDto ledgerDto);
	
	List<LedgerDto> getLedger();
	
	ItemMasterVO getItem(String itemUuid);
	
	List<ItemMasterVO> getItemMaster(String uuid,int page);
	
	String updateItemMaster(ItemMasterDto itemMasterDto);
	


}
