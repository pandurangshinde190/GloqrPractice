
package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity

@Table(name = "b_account_master")
public class AccountMaster extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "account_master_id")
	private Long accountMasterId;

	@Column(name = "account_master_uuid", nullable = false, updatable = false)
	private String accountMasterUuid;

	@Column(name = "account_group")
	private String accountGroup;

	@Column(name = "account_group_name")
	private String accountGroupName;

	@Column(name = "percentage_group_id")
	private String percentageGroupId;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "parent_group_id")
	private AccountMaster parentGroup;
	
	public AccountMaster() {
		super();
		// TODO Auto-generated constructor stub
	}




	public String getAccountMasterUuid() {
		return accountMasterUuid;
	}

	public void setAccountMasterUuid(String accountMasterUuid) {
		this.accountMasterUuid = accountMasterUuid;
	}

	public String getAccountGroup() {
		return accountGroup;
	}

	public void setAccountGroup(String accountGroup) {
		this.accountGroup = accountGroup;
	}

	public String getAccountGroupName() {
		return accountGroupName;
	}

	public void setAccountGroupName(String accountGroupName) {
		this.accountGroupName = accountGroupName;
	}

	public String getPercentageGroupId() {
		return percentageGroupId;
	}

	public void setPercentageGroupId(String percentageGroupId) {
		this.percentageGroupId = percentageGroupId;
	}

	public AccountMaster getParentGroup() {
		return parentGroup;
	}

	public void setParentGroup(AccountMaster parentGroup) {
		this.parentGroup = parentGroup;
	}

}
