package com.gloqr.books.dto;

import java.util.Date;

import javax.persistence.Column;

public class ContactPersonDto {

	private String contactPersonUuid;
	
	private String contactPersonName;

	private String designation;

	private String department;

	private String contactPhone;

	private String contactMobile;

	private String contactEmail;

	private Date dateOfBirth;
	
	private Boolean isDefault;

	public String getContactPersonUuid() {
		return contactPersonUuid;
	}

	public void setContactPersonUuid(String contactPersonUuid) {
		this.contactPersonUuid = contactPersonUuid;
	}

	
	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	

	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}
	
	

}
