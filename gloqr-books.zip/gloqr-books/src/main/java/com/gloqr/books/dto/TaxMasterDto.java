package com.gloqr.books.dto;


import com.gloqr.books.entities.Ledger;

public class TaxMasterDto {

	private String taxMasterUuid;

	private String name;

	private String type;

	private int percentage;
	
	private Ledger ledgerId;
	

	public String getTaxMasterUuid() {
		return taxMasterUuid;
	}

	public void setTaxMasterUuid(String taxMasterUuid) {
		this.taxMasterUuid = taxMasterUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public Ledger getLedgerId() {
		return ledgerId;
	}

	public void setLedgerId(Ledger ledgerId) {
		this.ledgerId = ledgerId;
	}
	
	
	
	
}
