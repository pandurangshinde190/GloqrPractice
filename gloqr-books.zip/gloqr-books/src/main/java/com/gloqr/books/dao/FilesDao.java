package com.gloqr.books.dao;

import java.util.List;

import com.gloqr.books.entities.Files;

public interface FilesDao {

	void saveFiles(List<Files> files);

}
