package com.gloqr.books.dto;



import com.gloqr.books.entities.Address;

public class SelfMasterDto {
	
private String selfMasterUuid;
	
	private String smeName;
	private Address address;
	private String logoImage;
	private String gstin;
	private String contactPhone;
	private String contactEmail;
	private String mobile;
	private String website;
	private String smeState;
	private String suuid;
	private String uuid;
	private String bookUuid;
	
	public String getSelfMasterUuid() {
		return selfMasterUuid;
	}
	public void setSelfMasterUuid(String selfMasterUuid) {
		this.selfMasterUuid = selfMasterUuid;
	}
	public String getSmeName() {
		return smeName;
	}
	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getLogoImage() {
		return logoImage;
	}
	public void setLogoImage(String logoImage) {
		this.logoImage = logoImage;
	}
	public String getGstin() {
		return gstin;
	}
	public void setGstin(String gstin) {
		this.gstin = gstin;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getSmeState() {
		return smeState;
	}
	public void setSmeState(String smeState) {
		this.smeState = smeState;
	}
	
	public String getSuuid() {
		return suuid;
	}
	public void setSuuid(String suuid) {
		this.suuid = suuid;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getBookUuid() {
		return bookUuid;
	}
	public void setBookUuid(String bookUuid) {
		this.bookUuid = bookUuid;
	}
	
	
		
	


}
