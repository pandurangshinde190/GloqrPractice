package com.gloqr.books.dto;

public class CustomerListDto {
	
	private String customerMUuid;

	private String customerName;

	private Boolean isDefault;
	
	public String getCustomerMUuid() {
		return customerMUuid;
	}

	public void setCustomerMUuid(String customerMUuid) {
		this.customerMUuid = customerMUuid;
	}

	

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

		
	
}
