package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.SelfMaster;

public interface SelfMasterRepo extends JpaRepository<SelfMaster, Long>{

	 boolean existsByUuid(String uuid);
	 
	 SelfMaster findBySuuid(String suuid);
	 
	 SelfMaster findByUuid(String uuid);
}
