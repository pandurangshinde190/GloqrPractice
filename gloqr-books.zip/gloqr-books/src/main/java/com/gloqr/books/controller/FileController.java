package com.gloqr.books.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.gloqr.books.constants.*;
import com.gloqr.books.constants.UrlMapping.FileDirectory;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.entities.Files;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.model.http.response.ResponseMessages;
import com.gloqr.books.security.context.holder.UserDetails;
import com.gloqr.books.services.FileService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;


@RestController
@CrossOrigin("*")
@RequestMapping(UrlMapping.ROOT_API)
public class FileController {
	
	@Autowired
	private ResponseMaker responseMaker;

	@Autowired
	private FileService fileService;

	@Autowired
	RequestParser requestParser;
	
	private static final Logger log = LogManager.getLogger();

	@PostMapping(UrlMapping.UPLOAD_FILES)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<Files>>> uploadBusinessPostFiles(
			@RequestParam(value = "files") MultipartFile[] multipartFiles) {
		
		String	smeId = requestParser.getSuuid();

		if (!(smeId != null && !smeId.equals("undefined")))
			throw new CustomException("value of 'smeId' param:- " + smeId + " is not valid", HttpStatus.BAD_REQUEST);

		log.info("Request for Upload Files for gloqr books by smeId: {}", smeId);

		List<Files> result = null;

		try {
			result = fileService.sendFilesToContentServer(Arrays.asList(multipartFiles),
					FileDirectory.FILE_DIR.replace("{smeId}", smeId));
		} catch (IllegalArgumentException | IOException e) {
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseMaker.successResponse(result, ResponseMessages.FILE_UPLODED, HttpStatus.OK);
	}

}
