package com.gloqr.books.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="b_uom")
public class UOM extends Audit implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "uom_id")
	private Long uomId;
	
	@Column(name="uom_uuid",updatable=false,nullable=false)
	private String uomUuid;
	
	@Column(name="name")
	private String name;
	
	@Column(name="base_unit")
	private String baseUnit;
	
	@Column(name="conversion")
	private String conversion;


	public String getUomUuid() {
		return uomUuid;
	}

	public void setUomUuid(String uomUuid) {
		this.uomUuid = uomUuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBaseUnit() {
		return baseUnit;
	}

	public void setBaseUnit(String baseUnit) {
		this.baseUnit = baseUnit;
	}

	public String getConversion() {
		return conversion;
	}

	public void setConversion(String conversion) {
		this.conversion = conversion;
	}

	public Long getUomId() {
		return uomId;
	}

	public void setUomId(Long uomId) {
		this.uomId = uomId;
	}
	
	

}
