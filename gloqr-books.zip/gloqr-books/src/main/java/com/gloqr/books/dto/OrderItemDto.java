package com.gloqr.books.dto;

import com.gloqr.books.constants.DiscountType;
import com.gloqr.books.constants.ItemType;

public class OrderItemDto {

	private String orderItemUuid;

	private String itemName;

	private int quantity;

	private double rate;

	private double discount;

	private double tax;

	private double amount;

	private DiscountType discountType;


	private String hsnSacCode;

	private ItemType type;
	
	private String uomUuid;
	
	private UOMMasterDto uomMasterDto;
	
	
	public String getOrderItemUuid() {
		return orderItemUuid;
	}

	public void setOrderItemUuid(String orderItemUuid) {
		this.orderItemUuid = orderItemUuid;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	
	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public DiscountType getDiscountType() {
		return discountType;
	}

	public void setDiscountType(DiscountType discountType) {
		this.discountType = discountType;
	}

	



	public String getHsnSacCode() {
		return hsnSacCode;
	}

	public void setHsnSacCode(String hsnSacCode) {
		this.hsnSacCode = hsnSacCode;
	}

	public ItemType getType() {
		return type;
	}

	public void setType(ItemType type) {
		this.type = type;
	}

	public String getUomUuid() {
		return uomUuid;
	}

	public void setUomUuid(String uomUuid) {
		this.uomUuid = uomUuid;
	}

	public UOMMasterDto getUomMasterDto() {
		return uomMasterDto;
	}

	public void setUomMasterDto(UOMMasterDto uomMasterDto) {
		this.uomMasterDto = uomMasterDto;
	}

}
