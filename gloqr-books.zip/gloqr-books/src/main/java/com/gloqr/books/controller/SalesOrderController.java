package com.gloqr.books.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.books.constants.Constants;
import com.gloqr.books.constants.UrlMapping;
import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.dto.ConsigneePersonListDto;
import com.gloqr.books.dto.ContactPersonListDto;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.SalesOrderVO;
import com.gloqr.books.services.SalesOrderService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class SalesOrderController {
	private static final Logger logger = LogManager.getLogger();
	@Autowired
	RequestParser requestParser;

	@Autowired
	ResponseMaker responseMaker;
																									
	@Autowired
	SalesOrderService salesOrderService;

	@PostMapping(UrlMapping.SALES_ORDER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> saveSalesOrder(@RequestBody SalesOrderDto salesOrderDto) {
		logger.info("Entering in saveSalesOrder() to save sales order details.");
		String suuid = requestParser.getSuuid();
		return responseMaker.successResponse(salesOrderService.saveSalesOrderDetails(salesOrderDto, suuid),
				HttpStatus.CREATED);
	}

	@GetMapping(UrlMapping.SALES_ORDER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<SalesOrderVO>>> getSalesOrderDetails(@RequestParam int page) {
		logger.info("Getting all sales order master detials from database");
		String uuid = requestParser.getUserUUID();
		List<SalesOrderVO> salesOrderDtos = salesOrderService.getSalesOrderDetails(uuid, page);
		return responseMaker.successResponse(salesOrderDtos, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_SALES_ORDER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<SalesOrderVO>> getSalesOrderDetail(@RequestParam String salesOrderUuid) {
		logger.info("Getting sales order detail to update");
		SalesOrderVO salesOrderVO = salesOrderService.getSalesOrder(salesOrderUuid);
		return responseMaker.successResponse(salesOrderVO, HttpStatus.OK);
	}
	
	@PutMapping(UrlMapping.SALES_ORDER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateSalesOrder(@RequestBody SalesOrderDto salesOrderDto) {
		logger.info("Updating a sales order details to the database");
		salesOrderService.updateSalesOrder(salesOrderDto);
		return responseMaker.successResponse("Update sales order successfully", HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.GET_BUSINESS_UNIT_FOR_CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<BusinessUnitListDto>>> getBusinessUnitDetail(@RequestParam String customerMUuid) {
		logger.info("Getting business unit details");
		List<BusinessUnitListDto> businessUnitListDto = salesOrderService.getBusinessUnitForCustomer(customerMUuid);
		return responseMaker.successResponse(businessUnitListDto, HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.GET_CONTACT_PERSON_FOR_CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ContactPersonListDto>>> getContactPersonDetail(@RequestParam String customerMUuid) {
		logger.info("Getting contact person detail to update");
		List<ContactPersonListDto> contactPersonListDtos = salesOrderService.getContactPersonForCustomer(customerMUuid);
		return responseMaker.successResponse(contactPersonListDtos, HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.GET_CONSIGNEE_PERSON_FOR_CUSTOMER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ConsigneePersonListDto>>> getConsigneePersonDetail(@RequestParam String customerMUuid) {
		logger.info("Getting consignee person detail to update");
		List<ConsigneePersonListDto> consigneePersonListDtos = salesOrderService.getConsigneePersonForCustomer(customerMUuid);
		return responseMaker.successResponse(consigneePersonListDtos, HttpStatus.OK);
	}
	
	@GetMapping(UrlMapping.GET_SELF_MASTER_STATE)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<Map<String, String>>> bookStatus() {
		logger.info("Getting self master state.");
		String tokenUserUuid = requestParser.getUserUUID();
		Map<String, String> selfMasterState = new HashMap<String, String>();
		selfMasterState = salesOrderService.getSelfMasterState(tokenUserUuid);
		return responseMaker.successResponse(selfMasterState, HttpStatus.OK);
	}

}


