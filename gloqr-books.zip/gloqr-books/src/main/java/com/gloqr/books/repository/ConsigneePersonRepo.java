package com.gloqr.books.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gloqr.books.entities.ConsigneePerson;

public interface ConsigneePersonRepo extends JpaRepository<ConsigneePerson, Long>{

	ConsigneePerson findByConsigneePersonUuid(String consigneePersonUuid);
}
