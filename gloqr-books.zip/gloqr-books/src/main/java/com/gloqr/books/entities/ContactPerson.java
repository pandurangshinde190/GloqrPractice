
package com.gloqr.books.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Table(name = "b_contact_person")
public class ContactPerson extends Audit implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "contact_person_id")
	private Long contactPersonId;

	@Column(name = "contact_person_uuid", nullable = false, updatable = false)
	private String contactPersonUuid;

	@Column(name = "is_default")
	private Boolean isDefault;
	
	
	@Column(name = "contact_person_name")
	private String contactPersonName;

	@Column(name = "designation")
	private String designation;

	@Column(name = "department")
	private String department;

	@Column(name = "phone")
	private String contactPhone;

	@Column(name = "mobile")
	private String contactMobile;

	@Column(name = "email")
	private String contactEmail;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	/*
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "customer_m_id")
	 * 
	 * @IndexedEmbedded(includeEmbeddedObjectId = true) private CustomerMaster
	 * customerMaster;
	 */

	/*
	 * public CustomerMaster getCustomerMaster() { return customerMaster; }
	 * 
	 * public void setCustomerMaster(CustomerMaster customerMaster) {
	 * this.customerMaster = customerMaster; }
	 */
	public String getContactPersonUuid() {
		return contactPersonUuid;
	}

	public void setContactPersonUuid(String contactPersonUuid) {
		this.contactPersonUuid = contactPersonUuid;
	}

	
	public String getContactMobile() {
		return contactMobile;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}



	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}
}
