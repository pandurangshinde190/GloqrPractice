package com.gloqr.books.services;

import java.util.List;

import com.gloqr.books.dto.ItemListDto;

public interface SearchService {

	public List<ItemListDto> getSearchItemSuggestions(String searchText, int maxResult,String uuid);
}
