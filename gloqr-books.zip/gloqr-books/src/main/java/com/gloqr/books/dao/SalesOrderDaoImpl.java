package com.gloqr.books.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.BusinessUnitListDto;
import com.gloqr.books.dto.CustomerMasterVO;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.SalesOrderDto;
import com.gloqr.books.dto.SalesOrderVO;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.CustomerMaster;
import com.gloqr.books.entities.Files;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.SalesOrder;
import com.gloqr.books.exception.CustomException;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.repository.BusinessUnitRepo;
import com.gloqr.books.repository.CustomerMasterRepo;
import com.gloqr.books.repository.FilesRepo;
import com.gloqr.books.repository.SalesOrderRepo;

@Repository
public class SalesOrderDaoImpl implements SalesOrderDao {
	private static final Logger logger = LogManager.getLogger();

	@Autowired
	SalesOrderRepo salesOrderRepo;

	@Autowired
	CustomerMasterRepo customerMasterRepo;

	@Autowired
	Mapper mapper;

	@Autowired
	FilesRepo filesRepo;
	
	@Autowired
	BusinessUnitRepo businessUnitRepo;
	
	@Override
	public String saveSalesOrderDetails(SalesOrder salesOrder) {
		logger.info("saving sales order details.");
		try {
			salesOrderRepo.save(salesOrder);
		} catch (Exception e) {
			throw new CustomException("Error while saving sales order details"+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return "sales order details has been saved successfully.";
	}

	@Override
	public List<SalesOrderVO> getSalesOrderDetails(String bookUuid, int page) {
		if (page <= 0)
			page = 1;
		List<SalesOrder> salesOrders = salesOrderRepo.findByBookUuid(bookUuid, PageRequest.of(--page, 20));
		List<SalesOrderVO> salesOrderVOs = new ArrayList<SalesOrderVO>();

		for (SalesOrder salesOrder : salesOrders) {
			SalesOrderVO salesOrderVO = new SalesOrderVO();

			salesOrderVO.setSalesOrderUuid(salesOrder.getSalesOrderUuid());
			
			salesOrderVO = mapper.convertToDto(salesOrder, SalesOrderVO.class);

//			if (salesOrder.getCustomerMaster() != null) {
//				CustomerMaster customerMaster = customerMasterRepo
//						.findByCustomerMUuid(salesOrder.getCustomerMaster().getCustomerMUuid());
//				CustomerMasterVO customerMasterVO = mapper.convertToDto(customerMaster, CustomerMasterVO.class);
//				salesOrderVO.setCustomerMaster(customerMasterVO);
//
//			}


			salesOrderVOs.add(salesOrderVO);

		}

		return salesOrderVOs;
	}

	@Override
	public SalesOrderVO getSalesOrder(String salesOrderUuid) {
		try {
			SalesOrder salesOrder = salesOrderRepo.findBySalesOrderUuid(salesOrderUuid);
			SalesOrderVO salesOrderVO = mapper.convertToDto(salesOrder,SalesOrderVO.class); 
			return salesOrderVO;
		}catch(Exception e) {
			throw new CustomException("Error while fetching sales order detail "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	
	}

	@Override
	public String updateSalesOrder(SalesOrder salesOrder) {
		logger.info("updating sales order details.");
		try {
			salesOrderRepo.save(salesOrder);
		} catch (Exception e) {
			throw new CustomException("Error while updating sales order details", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return "sales order details has been updated successfully.";
	}

	@Override
	public void updateFiles(List<Files> fileList) {

		logger.info("updating Files");
		try {
			filesRepo.saveAll(fileList);
		} catch (Exception e) {
			throw new CustomException("Error while updating files", HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}

}
