package com.gloqr.books.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gloqr.books.constants.Constants;
import com.gloqr.books.constants.UrlMapping;
import com.gloqr.books.dto.AccountMasterDto;
import com.gloqr.books.dto.CustomHttpResponse;
import com.gloqr.books.dto.ItemMasterDto;
import com.gloqr.books.dto.ItemMasterVO;
import com.gloqr.books.dto.LedgerDto;
import com.gloqr.books.dto.TaxMasterDto;
import com.gloqr.books.dto.UOMMasterDto;
import com.gloqr.books.entities.ItemMaster;
import com.gloqr.books.entities.TaxMaster;
import com.gloqr.books.mapper.Mapper;
import com.gloqr.books.security.context.holder.UserDetails;
import com.gloqr.books.services.ItemMasterService;
import com.gloqr.books.util.RequestParser;
import com.gloqr.books.util.ResponseMaker;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(UrlMapping.ROOT_API)
@SuppressWarnings("rawtypes")
public class ItemMasterController {

	public static final Logger logger = LogManager.getLogger();

	@Autowired
	ResponseMaker responseMaker;

	@Autowired
	ItemMasterService itemMasterService;

	
	@Autowired
	RequestParser requestParser;
	
	//POST API'S 
	@PostMapping(UrlMapping.ITEM)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> addItem(@Valid @RequestBody ItemMasterDto itemMasterDto) {
		logger.info("Adding a new Item");
		String uuid = requestParser.getUserUUID();
		String value = itemMasterService.addItemMaster(itemMasterDto,uuid);	
		return responseMaker.successResponse(value,HttpStatus.OK);	
	}




	@PostMapping(UrlMapping.TAX_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> postTaxMaster(@Valid @RequestBody TaxMasterDto taxMasterDto) {
		logger.info("Saving a tax master details to the database");
		String status = itemMasterService.saveTaxMasterDetails(taxMasterDto);
		return responseMaker.successResponse(status, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.UOM_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> postUomMaster(@Valid @RequestBody UOMMasterDto uomMasterDto) {
		logger.info("Saving a uom master details to the database");
		String status = itemMasterService.saveUomMasterDetails(uomMasterDto);
		return responseMaker.successResponse(status, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.ACCOUNT_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> postAccountMaster(
			@Valid @RequestBody AccountMasterDto accountMasterDto) {
		logger.info("Saving account master details to the database");
		String status = itemMasterService.saveAccountMasterDetails(accountMasterDto);
		return responseMaker.successResponse(status, HttpStatus.OK);
	}

	@PostMapping(UrlMapping.LEDGER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> ledger(@Valid @RequestBody LedgerDto ledgerDto) {
		logger.info("Saving a ledger master details to the database");
		String status = itemMasterService.saveLedger(ledgerDto);
		return responseMaker.successResponse(status, HttpStatus.OK);
	}

	// GET API'S

	@GetMapping(UrlMapping.ITEM)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<ItemMasterVO>>> getItem(@RequestParam int page) {
		logger.info("Getting all item master detials from database");
		String uuid=requestParser.getUserUUID();
		List<ItemMasterVO> itemMasterVO = itemMasterService.getItemMaster(uuid, page);
		return responseMaker.successResponse(itemMasterVO, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.TAX_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<TaxMasterDto>>> getTaxDetails() {
		logger.info("Getting a tax details from database");
		List<TaxMasterDto> taxMaster = itemMasterService.getTaxMaster();
		return responseMaker.successResponse(taxMaster, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.UOM_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<UOMMasterDto>>> getUomDetails() {
		logger.info("Getting a uom master details from database");
		List<UOMMasterDto> uomMasterDto = itemMasterService.getUomMaster();
		return responseMaker.successResponse(uomMasterDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.ACCOUNT_MASTER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<AccountMasterDto>>> getAccountDetails() {
		logger.info("Getting account master details from database");
		List<AccountMasterDto> accountDto = itemMasterService.getAccountMaster();
		return responseMaker.successResponse(accountDto, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.LEDGER)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<List<LedgerDto>>> ledger() {
		logger.info("Getting a ledger master details from the database");
		List<LedgerDto> ledger = itemMasterService.getLedger();
		return responseMaker.successResponse(ledger, HttpStatus.OK);
	}

	@GetMapping(UrlMapping.GET_ITEM)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<ItemMasterVO>> itemMaster(@RequestParam String itemUuid) {
		logger.info("Getting a item master details from the database");
		ItemMasterVO itemMasterVO = itemMasterService.getItem(itemUuid);
		return responseMaker.successResponse(itemMasterVO, HttpStatus.OK);
	}

	// PUT API'S
	@PutMapping(UrlMapping.ITEM)
	@PreAuthorize(Constants.ROLE_SME)
	public ResponseEntity<CustomHttpResponse<String>> updateItem(@RequestBody ItemMasterDto itemMasterDto) {
		logger.info("Updating a item master details to the database");
		itemMasterService.updateItemMaster(itemMasterDto);
		return responseMaker.successResponse("Update item successfyully", HttpStatus.OK);
	}
}
