package com.gloqr.books;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GloqrBooksApplicationTests {

	
	void contextLoads() {
	}

}
