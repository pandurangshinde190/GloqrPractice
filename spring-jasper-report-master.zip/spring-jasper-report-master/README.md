# spring-jasper-report
How to generate dynamic report using spring boot and jasper

*Download JasperSoft Studio tool*
Link : https://community.jaspersoft.com/project/jaspersoft-studio/releases
